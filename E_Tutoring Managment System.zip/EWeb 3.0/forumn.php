<?php
//This page displays the list of the forum's categories
session_start();

 include_once 'include/class.user.php';
   $Date_Posted = date('Y-m-d');
    $Time= date_create();
  $Time_Posted = date_format($Time,"h:m:s");
   $user = new User();
    $uid = $_SESSION['User_ID'];

    if (!$user->get_session()){
       header("location:login.php");
    }

    if (isset($_GET['q'])){
        $user->user_logout();
        header("location:login.php");
        

    }
    if(isset($_POST['submit'])){
        
        extract($_POST);
        $Post = $user->postToforumn($uid,$blog_title,$blog_content,$Date_Posted,$Time_Posted);
        
        ?> <script>alert("succesfully Posted! with file")</script>
      <?php
    }

?>

   <!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Homepage</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ETUTORING</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/user.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="css/dashstyle.css">

    <!--  -->
<link href="css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN"
        crossorigin="anonymous">

<link href="css/displaycss.css" rel="stylesheet" id="bootstrap-css">
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link href="css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN"
        crossorigin="anonymous">
        
<script src="js/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
 <script src="js/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
        crossorigin="anonymous"></script>
<script src="js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" ></script>
<nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container">
            <div class="navbar-header"><a class="navbar-brand navbar-link" href="StudentHome.php"><i class="fa fa-fw fa-user"></i> Student Account</a>
                
                
            
                <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            </div>



            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="nav navbar-nav navbar-right">
                   <li class="">
                        <a href="StudentHome.php"><i class="fa fa-fw fa-home fa-2x"></i> Dashboard</a>
                    </li>
                    <li>
                        <a href="StudentMessage.php"><i class="fa fa-fw fa-wechat fa-2x"></i> Messages</a>
                    </li>
                    

                    <li>
                        <a href="ViewMeetings.php"><i class="fa fa-fw fa-calendar fa-2x"></i> Meetings</a>
                    </li>

                    <li>
                        <a href="Forumn.php"><i class="fa fa-fw fa-twitter fa-2x"></i> Blog</a>
                    </li>

                     <li role="presentation"><a href="logout.php?q=logout"><i class="fa fa-fw fa-undo fa-2x"></i>Logout</a></li>

                    
                    
                </ul>
            </div>
        </div>
    </nav>
<br><br><br><br>
    </body>


    </html>
    <div class="container">
    <div class="text-center">
    <h3 class="3-bold w3-animate-zoom">Recent Discussions</h3>
<br>
</div>
</div>



              <?
              $Forumn = $user->getPostedForums($uid);
              while( $row=mysqli_fetch_array($Forumn)){
             
              ?>
              <div class="col-md-4">
              <?  
              $User_ID = $row['User_ID'];
              $Blog_ID = $row['Blog_ID'];
               
     ?>

        
              <div class="thumbnail" >
                <span class=""></span>
                <div class="text-center">
                <img src="blog_3.jpg">

            </div>
          <h3><? echo $row['Blog_Title'];?></h3>
          <h6> Date :<?echo $row['Date_Posted'];?></h6>
           <h8>Time Posted:<? echo $row['Time_Posted'];?></h8><br>
           <h9> by:<?php $user->get_Username($User_ID); ?></h9>
            
          <p><a  class="btn btn-primary btn-sm" href="full-Forumn2.php?Blog_ID=<?echo $row['Blog_ID'];?>&Blog_Title=<?echo $row['Blog_Title']; ?>" >Read More..</a></p>
          <p>Comments |(<?$user->countComments($Blog_ID);?>)</p>
        </div>
      </div>
</div>
         <?
              }
              ?>

</div>
</div>
</div>
  <div class="row">
<section>

 
  <div class="thumbnail text-center">
<h2> Scheduled Meetings</h2>
<p>View All Meetings</p>

    
  </div>




</section>
</div>
<a href="#" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal" >Start New Conversation</a>
<!-- this is the start of the modal< -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">New Discussion</h4>
      </div>
      <div class="modal-body">
  <form action="#" method="post">
    Please fill this form to Start a new Discussion:<br/>
        <label for="title">Title</label><br>
        <input type="text" value="" id="title" name="blog_title" /><br/>
             
        <label for="blog_content">Content</label><br>       
        <textarea cols="100" rows="5" id="blog_content" name="blog_content" required="" style="width: 50%;" ></textarea><br />
    <input type="submit" name="submit" value="Post" class="btn btn-info btn-lg">
    </form>
      
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

    <div class="foot"><a style="position: relative;"> E-learn Forumn</a><a href="index.html?q=logout" style="float: right;">Log Out:(<?php $user->get_fullname($uid); ?>) </a></div>

    <div class="modal fade" id="forumn" role="dialog">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h4>blog</h4> 
          </div>
          

        </div>
        

      </div>

    </div>
      <?

include_once ('footer.php');
    ?>
    <script src="js/jquery.min.js"></script>
    <script src="js/modal.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>