

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Messaging</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/user.css">
</head>
<nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container">
            <div class="navbar-header"><a class="navbar-brand navbar-link " > <i class="fa fa-fw fa-user"></i>Student Account </a>
                <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            </div>
            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="nav navbar-nav navbar-right">
                    <li class="">
                        <a href="StudentHome.php"><i class="fa fa-fw fa-archive"></i> Dashboard</a>
                    </li>
                    <li>
                        <a href="StudentMessage.php"><i class="fa fa-fw fa-facebook"></i> Messages</a>
                    </li>

 <li>
                        <a href="ViewMeetings.php"><i class="fa fa-fw fa-calendar"></i> Meetings</a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-fw fa-twitter"></i> Blog</a>
                    </li>


                    
                    
                    <li role="presentation"><a href="logout.php?q=logout">Logout</a></li>
                    
                </ul>
            </div>
        </div>
    </nav>



    
  
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>