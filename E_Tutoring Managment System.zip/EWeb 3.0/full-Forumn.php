<?php
session_start();
?>
<?php // require_once('connect.php'); ?>
<?

 include_once 'include/class.user.php';
   $user = new User();
    $uid = $_SESSION['User_ID'];

    if (!$user->get_session()){
       header("location:login.php");
    }

    if (isset($_GET['q'])){
        $user->user_logout();
        header("location:login.php");
        

    }
    $Blog_ID = $_GET['Blog_ID'];
?>


     <html>
     <titlle></title>

     <head>



     
     <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/user.css">
     <link rel="stylesheet" href="assets/w3.css">
</head>
<body>
<div class="head">
<nav class="navbar navbar-inverse">
        <div class="container">
            <div class="navbar-header"><a class="navbar-brand navbar-link" href="#">Student Account </a>
                <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            </div>
            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="nav navbar-nav navbar-right">
                    <li role="presentation"><a href="home.php">Dashboard</a></li>
                    <li role="presentation"><a href="StudentMessage.php">Messages </a></li>
                    <li role="presentation"><a href="#">Events</a></li>
                    <li role="presentation"><a href="#">Meetings</a></li>
                    <li role="presentation"><a href="#">Blog</a></li>
                    <li role="presentation"><a href="#">Tutors </a></li>
                    <li role="presentation"><a href="#">Courses</a></li>
                    
                </ul>
            </div>
        </div>
    </nav>
    </div>


    </body>


    </html>

  <form action="" method="post">
   <h3>You Can Also Include A File</h3>
        <input type="file" name="file">  
        <input type="submit" class="btn btn-success" name="submit" value="submit"><br>
<?php
$name = $_FILES['file']['name'];
 $size = $_FILES['file']['size'];
$tmp_name = $_FILES['file']['tmp_name'];

if (isset($name)){
if(!empty($name)){

    $location = 'upload/';

    if(move_uploaded_file($tmp_name,$location.$name)){

echo "uploaded file". $name;

    }
}else{
 echo 'please choose a file ';

}



}
 ?>     
</form>   


  
    <form >


    <table width="100%">
      <?php
//getting id from url
$Blog_ID = $_GET['Blog_ID'];

//selecting data associated with this particular id
  


       $Forumn = $user->getSelectedForum($Blog_ID);

       
        

// echo "<table><tr><th>ID</th><th>Name</th><th>E-mail</th><th>Gender</th><th>Birth Date</th><th>Website</th><th>Address</th><th>Province</th><th>Zip Code</th><th>City</th><th>Join Date</th><th>Annual Basic Pay</th></tr>";

while($row = mysqli_fetch_array($Forumn))
{
    $Blog_ID = $row['Blog_ID'];
    $Content = $row["Blog_Content"];
    $Title = $row["Blog_Title"];
     $date = $row["Date_Posted"];
     $time = $row['Time_Posted'];
  
}
?>

<div class="panel panel-default" style="width: 50%; ">
<div class="panel-heading">
<h3 class="panel-title text-center" >HEADING :<?echo $Title;?></h3>
<h5 class ="panel-title text-center">Date : <?echo $date?></h5>
<h5 class ="panel-title text-center">Time : <?echo $time?></h5>
</div>

<div class="panel-body text-center">
 <h2><? echo $Content;   ?></h2>

</div>


</div>


    
  <td colspan='2'>
    <p>Comments(<?$user->countComments($Blog_ID);?>) </p>
<tr><td colspan='2'><button class="btn btn-lg btn-primary" type="submit" data-toggle="modal" data-target="#myModal">Add A Comment</button>
  <hr/>
  <div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Modal Header</h4>
      </div>
      <div class="modal-body">
        <p>Some text in the modal.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
      

<h1 class="bottom_f w3-text-blue w3-card-2 w3-padding">Recent Comments..</h1>


</table>
</form>

  </div>

  <form method="post" action="">
    <table width="100%">
<?
$Blog_ID = $_GET['Blog_ID'];

//selecting data associated with this particular id
  


       $Forumn = $user->DisPCom($Blog_ID);
       while ($row = mysqli_fetch_array($Forumn)) {
        ?>
          <div id="wrapper">
        <tr><h6 style=""><?echo $row['Comment_Detail'];?></h6></tr>
        <?
        $User_ID = $row['User_ID'];
        
        
        
        
        ?>
        <p  class="3-bold w3-animate-zoom" style="text-transform:none; float: ;">by:<?php $user->get_Username($User_ID); ?></p></tr>
         <tr></tr>
       </div>

       <?  # code...
       }



?>





    </table>
    </form>
  </div>
  <div id="footer">
   
  <!-- end #footer -->
  </div>
<!-- end #container -->
</div>
</div>
</body>
</html>