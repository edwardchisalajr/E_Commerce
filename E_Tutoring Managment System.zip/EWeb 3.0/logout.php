<?

session_start();

include 'include/class.user.php';

if(isset($_GET['q'])){
	$user = new User();
    $user->user_logout();
    header("location:login.php");
    
}
?>