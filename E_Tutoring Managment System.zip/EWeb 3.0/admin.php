<?php 
include 'include/class.user.php';
include 'include/class.admin.php';
$admin = new admin();
// Checking for user logged in or not
    /*if (!$user->get_session())
    {
       header("location:index.php");
    }*/

?>
  <!DOCTYPE html>
  <html lang="en">

  <head>
   <meta charset="utf-8">
    <title>E Tutoring - Registration Form</title>
   <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css"> 
  <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap-theme.css"> 
  <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap-theme.min.css"> 
    <link rel="stylesheet" href="assets/css/Pretty-Registration-Form.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="styles.css">
  </head>

  <body>
 
            <nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container">
            <div class="navbar-header"><a class="navbar-brand navbar-link" href="AdminDash.php"><i class="fa fa-fw fa-user "></i> Admin Account</a>
                
                
            
                <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            </div>



            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="nav navbar-nav navbar-right">
                   <li class="">
                        <a href="AdminDash.php"><i class="fa fa-fw fa-home fa-2x"></i> Dashboard</a>
                    </li>
                    <li>
                        <a href="AssignStudents.php"><i class="fa fa-users fa-fw fa-2x"></i> Assing student</a>
                    </li>
                    <li>
                        <a href="admin.php"><i class="fa fa-fw fa-user fa-2x"></i>Add tutor</a>
                    </li>
                    

                    

                 
                    <li role="presentation"><a href="logout.php?q=logout"><i class="fa fa-fw fa-undo fa-2x"></i>Logout</a></li>


                    
                    
                </ul>
            </div>
        </div>
    </nav>
    <div class="row register-form">
        <div class="col-md-8 col-md-offset-2">
            <form class="form-horizontal custom-form" method="post"name ="reg">
   
      <h1>Add Tutor Form</h1>
      <?php
if (isset($_POST['submit'])){
        extract($_POST);
        $register = $admin->reg_user($uname, $Firstname, $Lastname, $uemail,$upass);
        if ($register) {
            // Registration Success
      $register = $admin->reg_tutor($uname,$upass,$qualification);
            echo "<div style='text-align:center'>Registration successful <a href='login.php'></div>";
             header("location:send-mail.php?uname=$uname&uemail=$uemail&upass=$upass;");
        } else {
            // Registration Failed
            echo "<div style='text-align:center'>Registration failed. Email or Username already exits please try again.</div>";
        }
    }


      ?>
      <br>
      <form>
        
      <div class="form-group">
        <div class="col-sm-4">
            <label class="control-label" for="name-input-field">First Name: </label>
        </div>
        <div class="col-sm-8">
            <input class="form-control" name="Firstname" required placeholder="Enter First Name" type="text">
        </div>
    </div>
      
    <div class="form-group">
      <div class="col-sm-4">
          <label class="control-label" for="name-input-field">Last Name: </label>
      </div>
      <div class="col-sm-8">
          <input class="form-control" type="text" name="Lastname" required placeholder="Enter Last Name">
      </div>
  </div>
  <div class="form-group">
    <div class="col-sm-4">
        <label class="control-label" for="name-input-field">Username:</label>
    </div>
    <div class="col-sm-8">
        <input class="form-control" type="text" name="uname" required placeholder="Enter Username">
    </div>
</div>
<div class="form-group">
  <div class="col-sm-4">
      <label class="control-label" for="email-input-field">Email: </label>
  </div>
  <div class="col-sm-8">
      <input class="form-control" type="email" name="uemail" required placeholder="Enter Email">
  </div>
</div>
<div class="form-group">
  <div class="col-sm-4">
      <label class="control-label" for="name-input-field">Qualification: </label>
  </div>
  <div class="col-sm-8">
      <input class="form-control" type="text" name="qualification" required placeholder="Upload Qualification">
  </div>
</div>

<div class="form-group">
    <div class="col-sm-4">
        <label class="control-label" for="pawssword-input-field">Enter Password: </label>
    </div>
    <div class="col-sm-8">
        <input class="form-control" type="password" name="upass" required  required placeholder="Enter Password:">
       
  </div>
    </div>
    
               
               <button class="btn btn-danger submit-button"  name="submit" value="Register" onclick="return(submitreg());" button type ="submit" type="button">Submit Form</button>
            <button class="btn btn-primary submit-button" button type ="reset" type="button">Clear Form</button>
            <br>
            <h1><a href="AssignStudents.php">Assign Students</a></h1>
          

        
      </form>
    

    <script>
      function submitreg() {
        var form = document.reg;
        if (form.uname.value == "") {
          alert("Enter Username.");
          return false;
        } else if (form.city.value == "") {
          alert("Enter city.");
          return false;
        } else if (form.upass.value == "") {
          alert("Enter password.");
          return false;
        } else if (form.Firstname.value == "") {
          alert("Enter FirstName.");
          return false;
		}else if (form.LastName.value == "") {
          alert("Enter LastName.");
          return false;
		}else if (form.uemail.value == "") {
          alert("Enter Email.");
          return false;
		}else if (form.Address.value == "") {
          alert("Enter Address.");
          return false;
        }
      }
    </script>
     <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js">
  </body>

  </html>