    <?php
session_start();
//This page let create a new personnal message
include_once ('include/class.user.php');
  $Date_Posted = date('Y-m-d');
	$Time= date_create();
  $Time_Posted = date_format($Time,"h:m:s");
 $user = new User();
    $uid = $_SESSION['User_ID'];

    if (!$user->get_session()){
       header("location:login.php");
    }

    if (isset($_GET['q'])){
        $user->user_logout();
        header("location:login.php");
    }

    if(isset($_POST['submit'])){
        
        extract($_POST);
        $Post = $user->postToforumn($uid,$blog_title,$blog_content,$Date_Posted,$Time_Posted);
        
        ?> <script>alert("succesfully Posted!")</script>
      <?php
    }

?>

     <html>
     <titlle></title>

     <head>



     
     <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/user.css">
</head>
<body>
<div class="head">
<nav class="navbar navbar-inverse">
        <div class="container">
            <div class="navbar-header"><a class="navbar-brand navbar-link" href="#">Student Account </a>
                <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            </div>
            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="nav navbar-nav navbar-right">
                    <li role="presentation"><a href="home.php">Dashboard</a></li>
                    <li role="presentation"><a href="StudentMessage.php">Messages </a></li>
                    <li role="presentation"><a href="#">Events</a></li>
                    <li role="presentation"><a href="#">Meetings</a></li>
                    <li role="presentation"><a href="#">Blog</a></li>
                    <li role="presentation"><a href="#">Tutors </a></li>
                    <li role="presentation"><a href="#">Courses</a></li>
                    
                </ul>
            </div>
        </div>
    </nav>
    </div>


    </body>             
    <div id = "wrapper" style="">
    <h1 style=""> Start New  Discussion</h1><br>
</div>
    <div id ="wrapper" style="">
    <form action="" method="post">
        Please fill this form to Start a new Discussion:<br/>
        <label for="title">Title</label><br>
        <input type="text" value="" id="title" name="blog_title" /><br/>
             
        <label for="blog_content">Content</label><br>       
        <textarea cols="100" rows="5" id="blog_content" name="blog_content" style=""></textarea><br />
        <h3>You Can Also Include A File</h3>
        <input type="file" class="btn btn-success" name="file"><br><br>     
        <input type="submit" class="btn btn-success" name="submit" value="submit"><br>
        
 
    </form>
</div>
</div>

         <div class="foot"><a style="position: relative;"> E-learn Forumn</a><a href="home.php?q=logout" style="float: right;">Log Out:(<?php $user->get_fullname($uid); ?>)</a></div>
    </body>

    <script>
Cufon.now();
    </script>
</html>