<?session_start();
include 'include/class.Tutor.php';
$Tutor = new Tutor();
		$TutorDetails = $Tutor->getTutorDetails($_SESSION['User_ID']);
		$tutorRow=mysqli_fetch_array($TutorDetails);
		$TutorID = $tutorRow['Tutor_id'];
		$_SESSION['Tutor_ID'] = $TutorID;
?>
<a href="TutorMessage.php">Message Students</a>