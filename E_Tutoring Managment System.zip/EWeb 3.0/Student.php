<?session_start();
include 'include/class.Student.php';
$Student = new Student();
		$TutorDetails = $Student->getStudentDetails($_SESSION['User_ID']);
		$StudentRow=mysqli_fetch_array($TutorDetails);
		$StudentID = $StudentRow['Student_ID'];
		$_SESSION['Student_ID'] = $StudentID;
?>
<a href="StudentMessage.php">Message Your Tutor</a>