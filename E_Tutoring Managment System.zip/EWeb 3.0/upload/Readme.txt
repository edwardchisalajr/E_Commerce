Files for NETTUTS Tutorial: How to create an object oriented blog using PHP Part 1
By Ben Mills - bmills@benmillsdesigns.com
----

To install this you need to do two things one change that MySQL connection in the includes/includes.php file to your database and in you need to create a MySQL database named what ever you would like and then import the nettuts_blog.sql file into that database, the sql file will create the database tables and give it a little bit of sample data.