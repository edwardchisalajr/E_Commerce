<?php
session_start();
?>
<?php // require_once('connect.php'); ?>
<?

 include_once 'include/class.user.php';
   $user = new User();


    $uid = $_SESSION['User_ID'];
    $Blog_ID =$_GET['Blog_ID'];

    if (!$user->get_session()){
       header("location:login.php");
    }

    if (isset($_GET['q'])){
        $user->user_logout();
        header("location:login.php");
        

    }


    if(isset($_POST['reply_submit'])){


    	$Comment_Detail = $_POST["Comment_Detail"];
        $Comment = $user->Comment($Blog_ID,$Comment_Detail,$uid);
        
            echo "<div style='text-align:center'>Comment successfuly sent</div>";
    }
    else{

         echo "<div style='text-align:center'>Comment Failed</div>";
         
   
    }
?>
<html>
     <titlle></title>

     <head>



     
     <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/w3.css">
    <link rel="stylesheet" href="assets/css/user.css">
</head>
<body>
<div class="head">
<nav class="navbar navbar-inverse">
        <div class="container">
            <div class="navbar-header"><a class="navbar-brand navbar-link" href="#">Student Account </a>
                <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            </div>
            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="nav navbar-nav navbar-right">
                    <li role="presentation"><a href="home.php">Dashboard</a></li>
                    <li role="presentation"><a href="StudentMessage.php">Messages </a></li>
                    <li role="presentation"><a href="#">Events</a></li>
                    <li role="presentation"><a href="#">Meetings</a></li>
                    <li role="presentation" class="active"><a href="forumn.php">Blog</a></li>
                    <li role="presentation"><a href="#">Tutors </a></li>
                    <li role="presentation"><a href="#">Courses</a></li>
                    
                </ul>
            </div>
        </div>
    </nav>
    </div>

<body>


<p><h3>Posting reply</h3></p>
<style type="text/css">


h3{
background-color:#CCCCCC;
text-align:center;

border:1px green solid;
}

</style>
</body>


<center><p><font color='brown'>You are logged in as(<?$user->get_fullname($uid);?>)</font> |<a href='logout.php'>Logout</a>|<a href='index.php'>Home</a></p></center>


<hr />
<br/><br/> 
<center>
<div id="content">
<form action="PostReply.php?Blog_ID=<?echo $Blog_ID?>" method="post">
<input type="text" name="Comment_Detail" placeholder="write Comment here">
<br /><br />

<button class="btn btn-lg btn-primary"  name="reply_submit" type="submit" value="post-Comment">Comment</button>
</form>
</div></center>
</html>
