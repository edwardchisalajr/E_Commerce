<?php 
// if(isset($_POST['submit'])){
require 'PHPMailerAutoload.php';
require 'class.smtp.php';
  $uemail = $_GET['uemail'];
       $Student_ID  =  $_GET['Student_ID'];
       $Tutor_ID = $_GET['Tutor_ID'];
$mail = new PHPMailer();


//	$mail->SMTPDebug = 2;                               // Enable verbose debug output

	$mail->isSMTP();                                      // Set mailer to use SMTP
	$mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
	$mail->SMTPAuth = true;                               // Enable SMTP authentication
	$mail->Username = 'group11nacit@gmail.com';                 // SMTP username
	$mail->Password = 'group11nacit265';                           // SMTP password
	$mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
	$mail->Port = 587;                                    // TCP port to connect to

	$mail->setFrom('group11nacit@gmail.com', 'Group 11 e_tutoring system(NACIT)');
	$mail->addAddress($uemail);     // Add a recipient
	
	$mail->addReplyTo('group11nacit@gmail.com');
	// $mail->addCC('cc@example.com');
	// $mail->addBCC('bcc@example.com');

	// $mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
	// $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
	$mail->isHTML(true);                             // Set email format to HTML

	$mail->Subject = 'Confirmation from E-tutoring System'."your<br> username is :".''.$uname."and your<br> password is :".''.$password;
	$mail->Body    = "You are now registered with NACIT e_tutoring system";
	$mail->AltBody = "Welcome";

	if(!$mail->send()) {
	    echo 'Message could not be sent.';
	    echo 'Mailer Error:'.$mail->ErrorInfo;
	    echo $Student_ID;
	    echo $Tutor_ID;
	  
       echo $uname;
  	} else {
	  
	    echo ' tutor'.$uname.''.'has been Assigned a new student'.''.'Confirmation Message has been sent';
	     

	}

//}
?> 