-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 18, 2018 at 12:01 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `e_web`
--
CREATE DATABASE `e_web` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `e_web`;

-- --------------------------------------------------------

--
-- Table structure for table `attachments_tbl`
--

CREATE TABLE `attachments_tbl` (
  `Attachments_ID` int(11) NOT NULL auto_increment,
  `Blog_ID` int(11) NOT NULL,
  `Location` varchar(100) NOT NULL,
  PRIMARY KEY  (`Attachments_ID`),
  KEY `Blog_ID` (`Blog_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `attachments_tbl`
--


-- --------------------------------------------------------

--
-- Table structure for table `blog_tbl`
--

CREATE TABLE `blog_tbl` (
  `Blog_ID` int(11) NOT NULL auto_increment,
  `Blog_Title` varchar(30) NOT NULL,
  `Blog_Content` varchar(100) NOT NULL,
  `User_ID` int(11) NOT NULL,
  PRIMARY KEY  (`Blog_ID`),
  KEY `User_ID` (`User_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `blog_tbl`
--


-- --------------------------------------------------------

--
-- Table structure for table `course_tbl`
--

CREATE TABLE `course_tbl` (
  `Course_ID` int(11) NOT NULL auto_increment,
  `Course_Name` varchar(30) NOT NULL,
  `Tutor_ID` int(11) NOT NULL,
  PRIMARY KEY  (`Course_ID`),
  KEY `Tutor_ID` (`Tutor_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `course_tbl`
--


-- --------------------------------------------------------

--
-- Table structure for table `event_tbl`
--

CREATE TABLE `event_tbl` (
  `Event_ID` int(11) NOT NULL auto_increment,
  `Event_Title` varchar(30) default NULL,
  `Event_Description` varchar(30) default NULL,
  `Event_Date` date default NULL,
  `Student_ID` int(11) NOT NULL,
  `Tutor_ID` int(11) NOT NULL,
  PRIMARY KEY  (`Event_ID`),
  KEY `Tutor_ID` (`Tutor_ID`),
  KEY `Student_ID` (`Student_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `event_tbl`
--


-- --------------------------------------------------------

--
-- Table structure for table `meeting_tbl`
--

CREATE TABLE `meeting_tbl` (
  `Meeting_ID` int(11) NOT NULL auto_increment,
  `Meeting_Subject` varchar(30) NOT NULL,
  `Meeting_Content` varchar(100) default NULL,
  `Meeting_Time` date default NULL,
  `Student_ID` int(11) NOT NULL,
  `Tutor_ID` int(11) NOT NULL,
  PRIMARY KEY  (`Meeting_ID`),
  KEY `Tutor_ID` (`Tutor_ID`),
  KEY `Student_ID` (`Student_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `meeting_tbl`
--


-- --------------------------------------------------------

--
-- Table structure for table `student_tbl`
--

CREATE TABLE `student_tbl` (
  `Student_ID` int(11) NOT NULL auto_increment,
  `User_ID` int(11) NOT NULL,
  `Address` varchar(30) default NULL,
  `city` varchar(30) default NULL,
  `DOB` date default NULL,
  `Gender` varchar(30) default NULL,
  `Course_ID` varchar(30) default NULL,
  PRIMARY KEY  (`Student_ID`),
  KEY `User_ID` (`User_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `student_tbl`
--

INSERT INTO `student_tbl` (`Student_ID`, `User_ID`, `Address`, `city`, `DOB`, `Gender`, `Course_ID`) VALUES
(1, 17, 'iunwiudniu', 'blantyre', '2018-09-03', 'Female', '1'),
(2, 19, 'aawwwewee', 'aaaaaaa', '2018-09-24', 'Female', '1'),
(3, 20, 'sdfghjk', 'blantyre', '2016-09-04', 'Male', '2'),
(4, 22, 'odwioidnoi', 'blaaubiiudbi', '2018-09-28', 'Female', '2'),
(5, 32, 'ubeiubciu', 'iuebfubiuaebif', '2018-09-20', 'Male', '2');

-- --------------------------------------------------------

--
-- Table structure for table `tutor_student_tbl`
--

CREATE TABLE `tutor_student_tbl` (
  `Tutor_Student_ID` int(11) NOT NULL auto_increment,
  `Tutor_ID` int(11) NOT NULL,
  `Student_id` int(11) NOT NULL,
  PRIMARY KEY  (`Tutor_Student_ID`),
  KEY `Tutor_ID` (`Tutor_ID`),
  KEY `Student_id` (`Student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tutor_student_tbl`
--


-- --------------------------------------------------------

--
-- Table structure for table `tutor_tbl`
--

CREATE TABLE `tutor_tbl` (
  `Tutor_id` int(11) NOT NULL auto_increment,
  `User_ID` int(11) NOT NULL,
  `Qualification` varchar(30) NOT NULL,
  PRIMARY KEY  (`Tutor_id`),
  KEY `User_ID` (`User_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tutor_tbl`
--

INSERT INTO `tutor_tbl` (`Tutor_id`, `User_ID`, `Qualification`) VALUES
(1, 26, 'masters in computer Science'),
(2, 27, 'sdfghjkl;'),
(3, 28, 'mastyer'),
(4, 29, 'mastyer'),
(5, 30, 'bachelors'),
(6, 31, 'phd');

-- --------------------------------------------------------

--
-- Table structure for table `user_tbl`
--

CREATE TABLE `user_tbl` (
  `User_ID` int(11) NOT NULL auto_increment,
  `fname` varchar(30) NOT NULL,
  `lname` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `user_type` varchar(30) NOT NULL,
  PRIMARY KEY  (`User_ID`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=33 ;

--
-- Dumping data for table `user_tbl`
--

INSERT INTO `user_tbl` (`User_ID`, `fname`, `lname`, `email`, `username`, `password`, `user_type`) VALUES
(15, '1', '1', '1@2', '1', '1', 'Student'),
(16, '111', '1', '3@g', '3', 'aaron', 'Student'),
(17, '1', '1', 'boilegendary265@gmail.com', 'aaron', '1', 'Student'),
(18, 'aaron', 'amasi', 'boilegendary265@gmail.com', 'legend', '12345', 'Student'),
(19, 'creare', 'uhuguga', 'a@wqwe', 'aaasddddff', 'ssssssss', 'Student'),
(20, '123456', 'dsea', 'asasas@d', 'asdasds', '123', 'Student'),
(21, 'khweamani', 'majiya', 'kahhwemmz@gmail.com', 'kwemmzy', 'khemzy', 'Student'),
(22, 'jbdbdbdbd', 'iwiwidwdb', 'iwhio@ind', 'iwhoiwnoi', '111111111', 'Student'),
(24, 'george', 'nyondo', 'george@gmail.com', 'nyondo265', 'nyondo265', 'Tutor'),
(26, 'mr', 'majiya', 'jiyaz@gmail.com', 'jiyaz', 'jiyaz', 'Tutor'),
(27, 'tyuiop', 'ertyui', 'sadfghj@dfghjk', 'ertyui', '313131', 'Tutor'),
(28, 'hhdhd', 'sjjs', 'sjsj@a', 'dbdi', '123', 'Tutor'),
(29, 'hhdhd', 'sjjs', 'sjsjsss@j', 'bvbsvsv', '6', 'Tutor'),
(30, 'legeneee', 'eieodon', 'inoino@hdm', 'ueubbbddddddddddd', 'nnnkkk', 'Tutor'),
(31, 'scscscs', 'scscscs', 'cscs@ff', 'sscscsc', 'asasas', 'Tutor'),
(32, 'wizo', 'wizo', 'wizo@jj', 'wizo', 'wizo', 'Student');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attachments_tbl`
--
ALTER TABLE `attachments_tbl`
  ADD CONSTRAINT `attachments_tbl_ibfk_1` FOREIGN KEY (`Blog_ID`) REFERENCES `blog_tbl` (`Blog_ID`);

--
-- Constraints for table `blog_tbl`
--
ALTER TABLE `blog_tbl`
  ADD CONSTRAINT `blog_tbl_ibfk_1` FOREIGN KEY (`User_ID`) REFERENCES `user_tbl` (`User_ID`);

--
-- Constraints for table `course_tbl`
--
ALTER TABLE `course_tbl`
  ADD CONSTRAINT `course_tbl_ibfk_1` FOREIGN KEY (`Tutor_ID`) REFERENCES `tutor_tbl` (`Tutor_id`);

--
-- Constraints for table `event_tbl`
--
ALTER TABLE `event_tbl`
  ADD CONSTRAINT `event_tbl_ibfk_1` FOREIGN KEY (`Tutor_ID`) REFERENCES `tutor_tbl` (`Tutor_id`),
  ADD CONSTRAINT `event_tbl_ibfk_2` FOREIGN KEY (`Student_ID`) REFERENCES `student_tbl` (`Student_ID`);

--
-- Constraints for table `meeting_tbl`
--
ALTER TABLE `meeting_tbl`
  ADD CONSTRAINT `meeting_tbl_ibfk_1` FOREIGN KEY (`Tutor_ID`) REFERENCES `tutor_tbl` (`Tutor_id`),
  ADD CONSTRAINT `meeting_tbl_ibfk_2` FOREIGN KEY (`Student_ID`) REFERENCES `student_tbl` (`Student_ID`);

--
-- Constraints for table `student_tbl`
--
ALTER TABLE `student_tbl`
  ADD CONSTRAINT `student_tbl_ibfk_1` FOREIGN KEY (`User_ID`) REFERENCES `user_tbl` (`User_ID`);

--
-- Constraints for table `tutor_student_tbl`
--
ALTER TABLE `tutor_student_tbl`
  ADD CONSTRAINT `tutor_student_tbl_ibfk_1` FOREIGN KEY (`Tutor_ID`) REFERENCES `tutor_tbl` (`Tutor_id`),
  ADD CONSTRAINT `tutor_student_tbl_ibfk_2` FOREIGN KEY (`Student_id`) REFERENCES `student_tbl` (`Student_ID`);

--
-- Constraints for table `tutor_tbl`
--
ALTER TABLE `tutor_tbl`
  ADD CONSTRAINT `tutor_tbl_ibfk_1` FOREIGN KEY (`User_ID`) REFERENCES `user_tbl` (`User_ID`);
