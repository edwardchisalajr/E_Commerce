<?php 
session_start();
    include_once 'include/class.user.php';
    include_once 'include/nav.php';
    $user = new User();

    $uid = $_SESSION['User_ID'];

    if (!$user->get_session()){
       header("location:login.php");
    }

    if (isset($_GET['q'])){
        $user->user_logout();
        header("location:login.php");
    }
?>
  <!DOCTYPE html>
  <html lang="en">

  <head>
    <meta charset="utf-8">
    <title>Home</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
  </head>

  <body>
    <div id="container" class="container">
      <div id="header">
        <a href="home.php?q=logout">LOGOUT</a>
      </div>
      <div id="main-body">
        <br/>
        <br/>
        <br/>
        <br/>
        <h1>
		
                  LOGGED IN AS: <?php $user->get_fullname($uid); ?>
				  <?	if($user->get_userType($uid)=="Admin"){
					  header("location:Admin.php");
				  }?>
    			</h1>
      </div>
      <div id="footer"></div>
    </div>
  </body>

  </html>