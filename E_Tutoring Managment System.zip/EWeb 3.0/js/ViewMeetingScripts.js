$(document).ready(function(){
	
        var calendar = $('#calendar').fullCalendar({  // assign calendar
      header: {
        left: 'prev,next today',
        center: 'title',
        right: 'month,agendaWeek,agendaDay,listWeek'
      },
            defaultView: 'month',
             
             
            allDaySlot: true,
			 
			eventOverlap: false,
            
            events: "ViewMeetingHandler.php?view=1",  // request to load current events
			
            
            eventClick:  function(event, jsEvent, view) {  // when some one click on any event
                endtime = $.fullCalendar.moment(event.end).format('h:mm');
                starttime = $.fullCalendar.moment(event.start).format('dddd, MMMM Do YYYY, h:mm');
                var mywhen = starttime + ' – ' + endtime;
                $('#modalTitle').html(event.title);
                $('#modalWhen').text(mywhen);
                $('#eventID').val(event.id);
                $('#calendarModal').modal();
            },
 
            select: function(start, end, jsEvent) { 
                endtime = $.fullCalendar.moment(end).format('h:mm');
                starttime = $.fullCalendar.moment(start).format('dddd, MMMM Do YYYY, h:mm');
                var mywhen = starttime + ' – ' + endtime;
                start = moment(start).format();
                end = moment(end).format();
                $('#createEventModal #startTime').val(start);
                $('#createEventModal #endTime').val(end);
                $('#createEventModal #when').text(mywhen);
                $('#createEventModal').modal('toggle');
           } 
        });
               
       $('#acceptButton').on('click', function(e){  
           e.preventDefault();
           doAccept(); 
       }); 
       $('#declineButton').on('click', function(e){  
           e.preventDefault();
           doDecline(); 
       });
       
       function doAccept(){  
           $("#calendarModal").modal('hide');
           var eventID = $('#eventID').val();
           $.ajax({
               url: 'ViewMeetingHandler.php',
               data: 'action=accept&id='+eventID,
               type: "POST",
               success: function(json) {
                   if(json == 1)
                         alert("Meeting Accepted");
                   else
                        return false;
                    
                   
               }
           });
       } 
        function doDecline(){  
           $("#calendarModal").modal('hide');
           var eventID = $('#eventID').val();
           $.ajax({
               url: 'ViewMeetingHandler.php',
               data: 'action=decline&id='+eventID,
               type: "POST",
               success: function(json) {
                   if(json == 1)
                        alert("Meeting Declined");
                   else
                        return false;
                    
                   
               }
           });
       } 
	   
    });