<?
include 'include/class.admin.php';
$admin = new Admin();
$User_ID = $_GET['UserID']; 
$TutorID = $admin->getTutorID($User_ID);
$TutorIDRow = mysqli_fetch_array($TutorID);
$TutorID = $TutorIDRow['Tutor_id'];


$today = date("Y-m-d");
$tempdate =  strtotime('-1 day',strtotime($today));
$yesterday = date("Y-m-d",$tempdate);
$tempdate =  strtotime('-2 day',strtotime($today));
$tminus2days = date("Y-m-d",$tempdate);
$tempdate =  strtotime('-3 day',strtotime($today));
$tminus3days = date("Y-m-d",$tempdate);
$tempdate =  strtotime('-4 day',strtotime($today));
$tminus4days = date("Y-m-d",$tempdate);
$tempdate =  strtotime('-5 day',strtotime($today));
$tminus5days = date("Y-m-d",$tempdate);
$tempdate =  strtotime('-6 day',strtotime($today));
$tminus6days = date("Y-m-d",$tempdate);

$TodayCountSentMessages = $admin->countSentMessages($User_ID,$today);
$TodayCountSentMessagesRows = mysqli_fetch_array($TodayCountSentMessages);
$TodayCountSentMessages = $TodayCountSentMessagesRows['sent'];


$yesterdayCountSentMessages = $admin->countSentMessages($User_ID,$yesterday);
$yesterdayCountSentMessagesRows = mysqli_fetch_array($yesterdayCountSentMessages);
$yesterdayCountSentMessages = $yesterdayCountSentMessagesRows['sent'];

$tminus2daysCountSentMessages = $admin->countSentMessages($User_ID,$tminus2days);
$tminus2daysCountSentMessagesRows = mysqli_fetch_array($tminus2daysCountSentMessages);
$tminus2daysCountSentMessages = $tminus2daysCountSentMessagesRows['sent'];


$tminus3daysCountSentMessages = $admin->countSentMessages($User_ID,$tminus3days);
$tminus3daysCountSentMessagesRows = mysqli_fetch_array($tminus3daysCountSentMessages);
$tminus3daysCountSentMessages = $tminus3daysCountSentMessagesRows['sent'];


$tminus4daysCountSentMessages = $admin->countSentMessages($User_ID,$tminus4days);
$tminus4daysCountSentMessagesRows = mysqli_fetch_array($tminus4daysCountSentMessages);
$tminus4daysCountSentMessages = $tminus4daysCountSentMessagesRows['sent'];


$tminus5daysCountSentMessages = $admin->countSentMessages($User_ID,$tminus5days);
$tminus5daysCountSentMessagesRows = mysqli_fetch_array($tminus5daysCountSentMessages);
$tminus5daysCountSentMessages = $tminus5daysCountSentMessagesRows['sent'];


$tminus6daysCountSentMessages = $admin->countSentMessages($User_ID,$tminus6days);
$tminus6daysCountSentMessagesRows = mysqli_fetch_array($tminus6daysCountSentMessages);
$tminus6daysCountSentMessages = $tminus6daysCountSentMessagesRows['sent'];

$TotalSentMessages = $tminus6daysCountSentMessages +$tminus5daysCountSentMessages + $tminus4daysCountSentMessages + $tminus3daysCountSentMessages +$tminus2daysCountSentMessages +$yesterdayCountSentMessages +  $TodayCountSentMessages;

$TodayRecievedCountMessages = $admin->countRecievedMessages($TutorID,$User_ID,$today);
$TodayRecievedCountMessagesRows = mysqli_fetch_array($TodayRecievedCountMessages);
$TodayRecievedCountMessages = $TodayRecievedCountMessagesRows['Recieved'];
 
 $yesterdayRecievedCountMessages = $admin->countRecievedMessages($TutorID,$User_ID,$yesterday);
$yesterdayRecievedCountMessagesRows = mysqli_fetch_array($yesterdayRecievedCountMessages);
$yesterdayRecievedCountMessages = $yesterdayRecievedCountMessagesRows['Recieved'];
 
 $tminus2RecievedCountMessages = $admin->countRecievedMessages($TutorID,$User_ID,$tminus2days);
$tminus2RecievedCountMessagesRows = mysqli_fetch_array($tminus2RecievedCountMessages);
$tminus2RecievedCountMessages = $tminus2RecievedCountMessagesRows['Recieved'];
 
 $tminus3RecievedCountMessages = $admin->countRecievedMessages($TutorID,$User_ID,$tminus3days);
$tminus3RecievedCountMessagesRows = mysqli_fetch_array($tminus3RecievedCountMessages);
$tminus3RecievedCountMessages = $tminus3RecievedCountMessagesRows['Recieved'];
 
 $tminus4RecievedCountMessages = $admin->countRecievedMessages($TutorID,$User_ID,$tminus4days);
$tminus4RecievedCountMessagesRows = mysqli_fetch_array($tminus4RecievedCountMessages);
$tminus4RecievedCountMessages = $tminus4RecievedCountMessagesRows['Recieved'];
 
 $tminus5RecievedCountMessages = $admin->countRecievedMessages($TutorID,$User_ID,$tminus5days);
$tminus5RecievedCountMessagesRows = mysqli_fetch_array($tminus5RecievedCountMessages);
$tminus5RecievedCountMessages = $tminus5RecievedCountMessagesRows['Recieved'];
 
 $tminus6RecievedCountMessages = $admin->countRecievedMessages($TutorID,$User_ID,$tminus6days);
$tminus6RecievedCountMessagesRows = mysqli_fetch_array($tminus6RecievedCountMessages);
$tminus6RecievedCountMessages = $tminus6RecievedCountMessagesRows['Recieved'];

$TotalRecievedMesseges = $tminus6RecievedCountMessages +$tminus5RecievedCountMessages +$tminus4RecievedCountMessages +$tminus3RecievedCountMessages +$tminus2RecievedCountMessages +  $yesterdayRecievedCountMessages + $TodayRecievedCountMessages;

$TotalMessages = $TotalSentMessages + $TotalRecievedMesseges;

@$SentPerc = $TotalSentMessages/$TotalMessages*100;
@$receivePerc = $TotalRecievedMesseges/$TotalMessages*100;

$averagesent = $TotalSentMessages/7;
$averagerecieved = $TotalRecievedMesseges/7;


?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Homepage</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ETUTORING</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/user.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="css/dashstyle.css">
<link rel="stylesheet" href="styl.css">

    <!--  -->
<link href="css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN"
        crossorigin="anonymous">

<link href="css/displaycss.css" rel="stylesheet" id="bootstrap-css">
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link href="css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN"
        crossorigin="anonymous">
<script>
window.onload = function () {
var today = new Date();
var todayDate = today.getDate();
var todayMonth = today.getMonth();
var todayYear = today.getFullYear();

var chart = new CanvasJS.Chart("chartContainer", {
	exportEnabled: true,
	animationEnabled: true,
	title: {
		text: "Number of Messages in the Last Seven Days"
	},
	axisX: {
		valueFormatString: "DDD",
		minimum: new Date(todayYear, todayMonth, todayDate-7, 23),
		maximum: new Date(todayYear, todayMonth, todayDate, 1)
	},
	axisY: {
		title: "Number of Messages"
	},
	legend: {
		verticalAlign: "top",
		horizontalAlign: "right",
		dockInsidePlotArea: true
	},
	toolTip: {
		shared: true
	},
	data: [{
		name: "Received",
		showInLegend: true,
		legendMarkerType: "square",
		type: "area",
		color: "rgba(40,175,101,0.6)",
		markerSize: 0,
		dataPoints: [ 
			{ x: new Date(todayYear, todayMonth, todayDate-6), y: <?echo $tminus6RecievedCountMessages;?> },
			{ x: new Date(todayYear, todayMonth, todayDate-5), y: <?echo $tminus5RecievedCountMessages;?> },
			{ x: new Date(todayYear, todayMonth, todayDate-4), y: <?echo $tminus4RecievedCountMessages;?> },
			{ x: new Date(todayYear, todayMonth, todayDate-3), y: <?echo $tminus3RecievedCountMessages;?>},
			{ x: new Date(todayYear, todayMonth, todayDate-2), y: <?echo $tminus2RecievedCountMessages;?> },
			{ x: new Date(todayYear, todayMonth, todayDate-1), y: <?echo $yesterdayRecievedCountMessages;?> },
			{ x: new Date(todayYear, todayMonth, todayDate), y: <?echo $TodayRecievedCountMessages;?> }
		]
	},
	{
		name: "Sent",
		showInLegend: true,
		legendMarkerType: "square",
		type: "area",
		color: "rgba(0,75,141,0.7)",
		markerSize: 0,
		dataPoints: [ 
			{ x: new Date(todayYear, todayMonth, todayDate-6), y: <?echo $tminus6daysCountSentMessages;?> },
			{ x: new Date(todayYear, todayMonth, todayDate-5), y: <?echo $tminus5daysCountSentMessages;?> },
			{ x: new Date(todayYear, todayMonth, todayDate-4), y: <?echo $tminus4daysCountSentMessages;?>  },
			{ x: new Date(todayYear, todayMonth, todayDate-3), y: <?echo $tminus3daysCountSentMessages;?> },
			{ x: new Date(todayYear, todayMonth, todayDate-2), y: <?echo $tminus2daysCountSentMessages;?>  },
			{ x: new Date(todayYear, todayMonth, todayDate-1), y: <?echo $yesterdayCountSentMessages;?>  },
			{ x: new Date(todayYear, todayMonth, todayDate), y: <?echo $TodayCountSentMessages;?>  }
		]
	}]
});
chart.render();

var chart = new CanvasJS.Chart("piechartContainer", {
	exportEnabled: true,
	animationEnabled: true,
	title:{
		text: "Total Messeges"
	},
	legend:{
		cursor: "pointer",
		itemclick: explodePie
	},
	data: [{
		type: "pie",

		showInLegend: true,
		toolTipContent: "{name}: <strong>{y}%</strong>",
		indexLabel: "{name} - {y}%",
		dataPoints: [
			{ y: <?echo $SentPerc?>, name: "Sent Messages", exploded: true },
			{ y: <?echo $receivePerc?>, name: "Received Messages", exploded: true  }

		]
	}]
});
chart.render();

function explodePie (e) {
	if(typeof (e.dataSeries.dataPoints[e.dataPointIndex].exploded) === "undefined" || !e.dataSeries.dataPoints[e.dataPointIndex].exploded) {
		e.dataSeries.dataPoints[e.dataPointIndex].exploded = true;
	} else {
		e.dataSeries.dataPoints[e.dataPointIndex].exploded = false;
	}
	e.chart.render();
}
}
</script>
</head>

<nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container">
            <div class="navbar-header"><a class="navbar-brand navbar-link" href="AdminDash.php"><i class="fa fa-fw fa-user "></i>Admin Account</a>
                
                
            
                <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            </div>



            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="nav navbar-nav navbar-right">
                   <li class="">
                        <a href="AdminDash.php"><i class="fa fa-fw fa-home fa-2x"></i> Dashboard</a>
                    </li>
                    <li>
                        <a href="AssignStudents.php"><i class="fa fa-users fa-fw fa-2x"></i> Assing student</a>
                    </li>
                    

                    

                    <li>
                        <a href="bootstrap-grid.html"><i class="fa fa-fw fa-twitter fa-2x"></i> Blog</a>
                    </li>

                    
                    
                </ul>
            </div>
        </div>
    </nav>
    <br><br><br><br>

    <div class="widget stacked widget-table action-table">
    				    <div class="container"> 
                            <div class="table-responsive">      
                            <table class="table">
				<div class="widget-header">
					<i class="icon-th-list"></i>
					<h3>Resign students</h3>
					<?php
					if(isset($_POST['chosen_students'])){
	
	foreach($_POST['chosen_students'] as $selected){
	$Studentdetails = $admin->getStudentDetails($selected);
	$studentRow=mysqli_fetch_array($Studentdetails);
	$Student_id = $studentRow['Student_ID'];
	$temptutorid = $_POST['Tutor'];
	$TutorDetails = $admin->getTutorDetails($temptutorid);
	$tutorRow=mysqli_fetch_array($TutorDetails);
	$tutor_id = $tutorRow['Tutor_id'];
	$Assign = $admin->ReAssignStudents($tutor_id,$Student_id);
	}
}



					?>

    <div class="widget-content">
	  <table class="table">
					<form action="#" method="post">
					<table class="table table-striped table-bordered">
						<thead>
							<tr>
								<th>First Name</th>
								<th>Last Name</th>
								<th>Email</th>
								<th>Re-Assign</th>
								<th class="td-actions"></th>
							</tr>
						</thead>
						<tbody >
							<tr>
							<?
							$Students = $admin->getAssignedStudents($TutorID);
							while( $row=mysqli_fetch_array($Students)){
				
							?>
								<td><?php echo $row['fname']; ?></td>
								<td><?php echo $row['lname']; ?></td>
								<td><?php echo $row['email']; ?></td>
								<td class="td-actions">
									<a href="javascript:;" class="btn btn-small btn-primary">
										<i class="btn-icon-only icon-ok"><input type="checkbox" name="chosen_students[]" value="<?php echo $row['User_ID'];?>"></i>										
									</a>
								</td>
							</tr>
							<?
							}
							?>
							
							
							</tbody>
						</table>
						<tr>
              <h6>Choose Tutor to Re-Assign Students</h6>
			  <select name = "Tutor">
			<?
							$Tutors = $admin->getTutors();
							while( $row=mysqli_fetch_array($Tutors)){
				
			?>
              
			  <option value ="<?php echo $row['User_ID']; ?>"><?php echo $row['fname']; ?></option>
		
			<?
							}
			?>
				  </select>
            
          
						<button type='submit' class="btn btn-danger" name="submit"><i class="fa fa-fw fa-hand-pointer-o"></i></button>
						</form>
					
                                
                                </table>
</div>

</div>
<br>

<div class="widget-content">
<div class="container bootstrap snippet">
<div id="chartContainer" style="height: 370px; max-width: 920px; margin: 0px auto;"></div>
		<script src="js/canvasjs.min.js"></script>
</div> 
<br>
<div class="container bootstrap snippet">
<div id="piechartContainer" style="height: 370px; max-width: 920px; margin: 0px auto;"></div>
		<script src="js/canvasjs.min.js"></script>
</div>  

	  
 </div>
 <br>
 <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
 </body