<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>E Web</title>
 <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
 
</head>

<body class="fixed-nav s" id="page-top">
  
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <a class="navbar-brand" href="StudentHome.php"><i class="fa fa-fw fa-user"></i>Tutor Account</a>

    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>



    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">
          <a class="nav-link" href="TutorHome.php">
            <i class="fa fa-fw fa-home fa-2x"></i>
            <span class="nav-link-text">Dashboard</span>
          </a>
        </li>

<li class="nav-item" data-toggle="tooltip" data-placement="right" title="Messages">
          <a class="nav-link" href="TutorMessage.php">
            <i class="fa fa-fw fa-wechat fa-2x"></i>
            <span class="nav-link-text">Messages</span>
          </a>
        </li>

<li class="nav-item" data-toggle="tooltip" data-placement="right" title="Meetings">
          <a class="nav-link" href="Meeting.php">
            <i class="fa fa-fw fa-calendar fa-2x"></i>
            <span class="nav-link-text">Meetings</span>
          </a>
        </li>


<li class="nav-item" data-toggle="tooltip" data-placement="right" title="Blog">
          <a class="nav-link" href="#">
            <i class="fa fa-fw fa-twitter fa-2x"></i>
            <span class="nav-link-text ">Blog</span>
          </a>
        </li>
       
                    

                    

                  
      
        
    </div>
  </nav>
  <br>  <br>  <br>