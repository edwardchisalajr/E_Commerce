<?php
include("config.php");
session_start();
$TutorID = $_SESSION['Tutor_ID'];
    
if(isset($_POST['action']) or isset($_GET['view'])) //show all events
{
    if(isset($_GET['view']))
    {
        header('Content-Type: application/json');
        $start = mysqli_real_escape_string($dbcon,$_GET["start"]);
        $end = mysqli_real_escape_string($dbcon,$_GET["end"]);
        
        $result = mysqli_query($dbcon,"SELECT Meeting_ID as id, start_time as start,end_time as end,Meeting_Subject as title FROM  meeting_tbl where Tutor_ID = $TutorID");
        while($row = mysqli_fetch_assoc($result))
        {
            $events[] = $row; 
        }
        echo json_encode($events); 
        exit;
    }
    elseif($_POST['action'] == "add") // add new event
    {   
        mysqli_query($dbcon,"INSERT INTO meeting_tbl(
                    Meeting_Subject ,
                    start_time ,
                    end_time ,
					Tutor_ID
                    )
                    VALUES (
                    '".mysqli_real_escape_string($dbcon,$_POST["title"])."',
                    '".mysqli_real_escape_string($dbcon,date('Y-m-d H:i:s',strtotime($_POST["start"])))."',
                    '".mysqli_real_escape_string($dbcon,date('Y-m-d H:i:s',strtotime("+30 minutes",strtotime($_POST["start"]))))."',
					'".mysqli_real_escape_string($dbcon,$_SESSION['Tutor_ID'])."'
                    )");
        header('Content-Type: application/json');
        echo '{"id":"'.mysqli_insert_id($dbcon).'"}';
        exit;
    }
    elseif($_POST['action'] == "update")  // update event
    {
        mysqli_query($dbcon,"UPDATE meeting_tbl set 
            start_time = '".mysqli_real_escape_string($dbcon,date('Y-m-d H:i:s',strtotime($_POST["start"])))."', 
            end_time = '".mysqli_real_escape_string($dbcon,date('Y-m-d H:i:s',strtotime($_POST["end"])))."' 
            where Meeting_ID = '".mysqli_real_escape_string($dbcon,$_POST["id"])."'");
        exit;
    }
    elseif($_POST['action'] == "delete")  // remove event
    {
        mysqli_query($dbcon,"DELETE from meeting_tbl where Meeting_ID = '".mysqli_real_escape_string($dbcon,$_POST["id"])."'");
        if (mysqli_affected_rows($dbcon) > 0) {
            echo "1";
        }
        exit;
    }
}
?>