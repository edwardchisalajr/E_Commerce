<?
include 'include/class.admin.php';
$admin = new Admin();
$User_ID = $_GET['UserID']; 
$StudentID = $admin->getStudentID($User_ID);
$StudentIDRow = mysqli_fetch_array($StudentID);
$StudentID = $StudentIDRow['Student_ID'];


$today = date("Y-m-d");
$tempdate =  strtotime('-1 day',strtotime($today));
$yesterday = date("Y-m-d",$tempdate);
$tempdate =  strtotime('-2 day',strtotime($today));
$tminus2days = date("Y-m-d",$tempdate);
$tempdate =  strtotime('-3 day',strtotime($today));
$tminus3days = date("Y-m-d",$tempdate);
$tempdate =  strtotime('-4 day',strtotime($today));
$tminus4days = date("Y-m-d",$tempdate);
$tempdate =  strtotime('-5 day',strtotime($today));
$tminus5days = date("Y-m-d",$tempdate);
$tempdate =  strtotime('-6 day',strtotime($today));
$tminus6days = date("Y-m-d",$tempdate);

$TodayCountSentMessages = $admin->countSentMessages($User_ID,$today);
$TodayCountSentMessagesRows = mysqli_fetch_array($TodayCountSentMessages);
$TodayCountSentMessages = $TodayCountSentMessagesRows['sent'];


$yesterdayCountSentMessages = $admin->countSentMessages($User_ID,$yesterday);
$yesterdayCountSentMessagesRows = mysqli_fetch_array($yesterdayCountSentMessages);
$yesterdayCountSentMessages = $yesterdayCountSentMessagesRows['sent'];

$tminus2daysCountSentMessages = $admin->countSentMessages($User_ID,$tminus2days);
$tminus2daysCountSentMessagesRows = mysqli_fetch_array($tminus2daysCountSentMessages);
$tminus2daysCountSentMessages = $tminus2daysCountSentMessagesRows['sent'];


$tminus3daysCountSentMessages = $admin->countSentMessages($User_ID,$tminus3days);
$tminus3daysCountSentMessagesRows = mysqli_fetch_array($tminus3daysCountSentMessages);
$tminus3daysCountSentMessages = $tminus3daysCountSentMessagesRows['sent'];


$tminus4daysCountSentMessages = $admin->countSentMessages($User_ID,$tminus4days);
$tminus4daysCountSentMessagesRows = mysqli_fetch_array($tminus4daysCountSentMessages);
$tminus4daysCountSentMessages = $tminus4daysCountSentMessagesRows['sent'];


$tminus5daysCountSentMessages = $admin->countSentMessages($User_ID,$tminus5days);
$tminus5daysCountSentMessagesRows = mysqli_fetch_array($tminus5daysCountSentMessages);
$tminus5daysCountSentMessages = $tminus5daysCountSentMessagesRows['sent'];


$tminus6daysCountSentMessages = $admin->countSentMessages($User_ID,$tminus6days);
$tminus6daysCountSentMessagesRows = mysqli_fetch_array($tminus6daysCountSentMessages);
$tminus6daysCountSentMessages = $tminus6daysCountSentMessagesRows['sent'];

$TotalSentMessages = $tminus6daysCountSentMessages +$tminus5daysCountSentMessages + $tminus4daysCountSentMessages + $tminus3daysCountSentMessages +$tminus2daysCountSentMessages +$yesterdayCountSentMessages +  $TodayCountSentMessages;

$TodayRecievedCountMessages = $admin->countStudentRecievedMessages($StudentID,$User_ID,$today);
$TodayRecievedCountMessagesRows = mysqli_fetch_array($TodayRecievedCountMessages);
$TodayRecievedCountMessages = $TodayRecievedCountMessagesRows['Recieved'];
 
 $yesterdayRecievedCountMessages = $admin->countStudentRecievedMessages($StudentID,$User_ID,$yesterday);
$yesterdayRecievedCountMessagesRows = mysqli_fetch_array($yesterdayRecievedCountMessages);
$yesterdayRecievedCountMessages = $yesterdayRecievedCountMessagesRows['Recieved'];
 
 $tminus2RecievedCountMessages = $admin->countStudentRecievedMessages($StudentID,$User_ID,$tminus2days);
$tminus2RecievedCountMessagesRows = mysqli_fetch_array($tminus2RecievedCountMessages);
$tminus2RecievedCountMessages = $tminus2RecievedCountMessagesRows['Recieved'];
 
 $tminus3RecievedCountMessages = $admin->countStudentRecievedMessages($StudentID,$User_ID,$tminus3days);
$tminus3RecievedCountMessagesRows = mysqli_fetch_array($tminus3RecievedCountMessages);
$tminus3RecievedCountMessages = $tminus3RecievedCountMessagesRows['Recieved'];
 
 $tminus4RecievedCountMessages = $admin->countStudentRecievedMessages($StudentID,$User_ID,$tminus4days);
$tminus4RecievedCountMessagesRows = mysqli_fetch_array($tminus4RecievedCountMessages);
$tminus4RecievedCountMessages = $tminus4RecievedCountMessagesRows['Recieved'];
 
 $tminus5RecievedCountMessages = $admin->countStudentRecievedMessages($StudentID,$User_ID,$tminus5days);
$tminus5RecievedCountMessagesRows = mysqli_fetch_array($tminus5RecievedCountMessages);
$tminus5RecievedCountMessages = $tminus5RecievedCountMessagesRows['Recieved'];
 
 $tminus6RecievedCountMessages = $admin->countStudentRecievedMessages($StudentID,$User_ID,$tminus6days);
$tminus6RecievedCountMessagesRows = mysqli_fetch_array($tminus6RecievedCountMessages);
$tminus6RecievedCountMessages = $tminus6RecievedCountMessagesRows['Recieved'];

$TotalRecievedMesseges = $tminus6RecievedCountMessages +$tminus5RecievedCountMessages +$tminus4RecievedCountMessages +$tminus3RecievedCountMessages +$tminus2RecievedCountMessages +  $yesterdayRecievedCountMessages + $TodayRecievedCountMessages;

$TotalMessages = $TotalSentMessages + $TotalRecievedMesseges;

@$SentPerc = $TotalSentMessages/$TotalMessages*100;
@$receivePerc = $TotalRecievedMesseges/$TotalMessages*100;

$averagesent = $TotalSentMessages/7;
$averagerecieved = $TotalRecievedMesseges/7;

$AcceptedMeetings = $admin->countAcceptedMeetings($StudentID);
$AcceptedMeetingsRows = mysqli_fetch_array($AcceptedMeetings);
$AcceptedMeetings = $AcceptedMeetingsRows['Accepted'];

$DeclinedMeetings = $admin->countDeniedMeetings($StudentID);
$DeclinedMeetingsRows = mysqli_fetch_array($DeclinedMeetings);
$DeclinedMeetings = $DeclinedMeetingsRows['Declined'];

$PendingMeetings = $admin->countPendingMeetings($StudentID);
$PendingMeetingsRows = mysqli_fetch_array($PendingMeetings);
$PendingMeetings = $PendingMeetingsRows['Pending'];

?>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Homepage</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ETUTORING</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/user.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="css/dashstyle.css">

    <!--  -->
<link href="css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN"
        crossorigin="anonymous">

<link href="css/displaycss.css" rel="stylesheet" id="bootstrap-css">
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link href="css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN"
        crossorigin="anonymous">
<script>
window.onload = function () {
var today = new Date();
var todayDate = today.getDate();
var todayMonth = today.getMonth();
var todayYear = today.getFullYear();

var chart = new CanvasJS.Chart("chartContainer", {
	exportEnabled: true,
	animationEnabled: true,
	title: {
		text: "Number of Messages in the Last Seven Days"
	},
	axisX: {
		valueFormatString: "DDD",
		minimum: new Date(todayYear, todayMonth, todayDate-7, 23),
		maximum: new Date(todayYear, todayMonth, todayDate, 1)
	},
	axisY: {
		title: "Number of Messages"
	},
	legend: {
		verticalAlign: "top",
		horizontalAlign: "right",
		dockInsidePlotArea: true
	},
	toolTip: {
		shared: true
	},
	data: [{
		name: "Received",
		showInLegend: true,
		legendMarkerType: "square",
		type: "area",
		color: "rgba(40,175,101,0.6)",
		markerSize: 0,
		dataPoints: [ 
			{ x: new Date(todayYear, todayMonth, todayDate-6), y: <?echo $tminus6RecievedCountMessages;?> },
			{ x: new Date(todayYear, todayMonth, todayDate-5), y: <?echo $tminus5RecievedCountMessages;?> },
			{ x: new Date(todayYear, todayMonth, todayDate-4), y: <?echo $tminus4RecievedCountMessages;?> },
			{ x: new Date(todayYear, todayMonth, todayDate-3), y: <?echo $tminus3RecievedCountMessages;?>},
			{ x: new Date(todayYear, todayMonth, todayDate-2), y: <?echo $tminus2RecievedCountMessages;?> },
			{ x: new Date(todayYear, todayMonth, todayDate-1), y: <?echo $yesterdayRecievedCountMessages;?> },
			{ x: new Date(todayYear, todayMonth, todayDate), y: <?echo $TodayRecievedCountMessages;?> }
		]
	},
	{
		name: "Sent",
		showInLegend: true,
		legendMarkerType: "square",
		type: "area",
		color: "rgba(0,75,141,0.7)",
		markerSize: 0,
		dataPoints: [ 
			{ x: new Date(todayYear, todayMonth, todayDate-6), y: <?echo $tminus6daysCountSentMessages;?> },
			{ x: new Date(todayYear, todayMonth, todayDate-5), y: <?echo $tminus5daysCountSentMessages;?> },
			{ x: new Date(todayYear, todayMonth, todayDate-4), y: <?echo $tminus4daysCountSentMessages;?>  },
			{ x: new Date(todayYear, todayMonth, todayDate-3), y: <?echo $tminus3daysCountSentMessages;?> },
			{ x: new Date(todayYear, todayMonth, todayDate-2), y: <?echo $tminus2daysCountSentMessages;?>  },
			{ x: new Date(todayYear, todayMonth, todayDate-1), y: <?echo $yesterdayCountSentMessages;?>  },
			{ x: new Date(todayYear, todayMonth, todayDate), y: <?echo $TodayCountSentMessages;?>  }
		]
	}]
});
chart.render();

var chart = new CanvasJS.Chart("piechartContainer", {
	exportEnabled: true,
	animationEnabled: true,
	title:{
		text: "Total Messeges"
	},
	legend:{
		cursor: "pointer",
		itemclick: explodePie
	},
	data: [{
		type: "pie",

		showInLegend: true,
		toolTipContent: "{name}: <strong>{y}%</strong>",
		indexLabel: "{name} - {y}%",
		dataPoints: [
			{ y: <?echo $SentPerc?>, name: "Sent Messages", exploded: true },
			{ y: <?echo $receivePerc?>, name: "Received Messages", exploded: true  }

		]
	}]
});
chart.render();

function explodePie (e) {
	if(typeof (e.dataSeries.dataPoints[e.dataPointIndex].exploded) === "undefined" || !e.dataSeries.dataPoints[e.dataPointIndex].exploded) {
		e.dataSeries.dataPoints[e.dataPointIndex].exploded = true;
	} else {
		e.dataSeries.dataPoints[e.dataPointIndex].exploded = false;
	}
	e.chart.render();
}
}
</script>


<nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container">
            <div class="navbar-header"><a class="navbar-brand navbar-link" href="AdminDash.php"><i class="fa fa-fw fa-user "></i> Viewing student Account</a>
                
                
            
                <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            </div>



            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="nav navbar-nav navbar-right">
                   <li class="">
                        <a href="AdminDash.php"><i class="fa fa-fw fa-home fa-2x"></i> Dashboard</a>
                    </li>
                    <li>
                        <a href="AssignStudents.php"><i class="fa fa-users fa-fw fa-2x"></i> Assing student</a>
                    </li>
                    

                    

                    <li>
                        <a href="bootstrap-grid.html"><i class="fa fa-fw fa-twitter fa-2x"></i> Blog</a>
                    </li>

                    
                    
                </ul>
            </div>
        </div>
    </nav>
    <br><br><br><br>
<div class="row align="right">

    <div class="col-lg-2">
      <div class="circle-tile ">
        <a href="#"><div class="circle-tile-heading blue"><i class="fa fa-users fa-fw fa-3x"></i></div></a>

        <div class="circle-tile-content blue">
          <div class="circle-tile-description text-faded"> Average sent Messages </div>
          <div class="circle-tile-number text-faded "><?echo $averagesent;?></div> 
        </div>
      </div>
    </div>
    
    
    <div class="col-lg-3 ">
      <div class="circle-tile ">
        <a href="#"><div class="circle-tile-heading red"><i class="fa fa-users fa-fw fa-3x"></i></div></a>
        <div class="circle-tile-content red">
          <div class="circle-tile-description text-faded"> Average Recieved Messages </div>
          <div class="circle-tile-number text-faded "><?echo $averagerecieved;?></div> 
          
        </div>
         </div>
      </div>
        <div class="col-lg-3 ">
      <div class="circle-tile ">
        <a href="#"><div class="circle-tile-heading blue"><i class="fa fa-users fa-fw fa-3x"></i></div></a>
        <div class="circle-tile-content blue">
          <div class="circle-tile-description text-faded"> Accepted Meetings</div>
          <div class="circle-tile-number text-faded "><?echo $AcceptedMeetings;?></div> 
          
        </div>
         </div>
      </div>
            <div class="col-lg-2 ">
      <div class="circle-tile ">
        <a href="#"><div class="circle-tile-heading red"><i class="fa fa-users fa-fw fa-3x"></i></div></a>
        <div class="circle-tile-content red">
          <div class="circle-tile-description text-faded"> Declined Meetings</div>
          <div class="circle-tile-number text-faded "><?echo $DeclinedMeetings;?></div> 
          
        </div>
         </div>
      </div>
                <div class="col-lg-2 ">
      <div class="circle-tile ">
        <a href="#"><div class="circle-tile-heading yellow"><i class="fa fa-users fa-fw fa-3x"></i></div></a>
        <div class="circle-tile-content yellow">
          <div class="circle-tile-description text-faded"> Pending Meetings</div>
          <div class="circle-tile-number text-faded "><?echo $PendingMeetings;?></div> 
          
        </div>
         </div>
      </div>
      
</div>

</div>
<br><br>

    <div class="container bootstrap snippet">
<div id="piechartContainer" style="height: 370px; max-width: 920px; margin: 0px auto;"></div>
        <script src="js/canvasjs.min.js"></script>
</div> 
<br><br>


    <div class="container bootstrap snippet">
<div id="chartContainer" style="height: 370px; max-width: 920px; margin: 0px auto;"></div>
        <script src="js/canvasjs.min.js"></script>
</div> 

 
  
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>
 