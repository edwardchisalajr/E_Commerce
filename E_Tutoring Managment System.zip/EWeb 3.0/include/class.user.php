<?php 
	include "db_config.php";
	class User{
		protected $db;
		public function __construct(){
			$this->db = new DB_con();
			$this->db = $this->db->ret_obj();
		}
		
		/*** for registration process ***/
		
		public function reg_user($uname, $Firstname, $Lastname, $uemail,$upass){
			//echo "k";

			//checking if the username or email is available in db
			$query = "SELECT * FROM user_tbl WHERE username='$uname' AND password='$upass'";
			
			$result = $this->db->query($query) or die($this->db->error);
			
			$count_row = $result->num_rows;
			
			//if the username is not in db then insert to the table
			
			if($count_row == 0){
				$query = "INSERT INTO user_tbl SET username='$uname', password='$upass', fname='$Firstname', email='$uemail', lname='$Lastname', user_type='Student',Visits = '0',Status = 'Pending'";
				
				$result = $this->db->query($query) or die($this->db->error);
				
				return true;
			}
			else{return false;}
			
			
			}
			public function reg_student($uname,$upass,$address, $city, $dob, $gender,$course_ID){
			//echo "k";

			//checking if the username or email is available in db
			$query = "SELECT * FROM user_tbl WHERE username='$uname' AND password = '$upass'";
			
			$result = $this->db->query($query) or die($this->db->error);
			
			$count_row = $result->num_rows;
			$user_data = $result->fetch_array(MYSQLI_ASSOC);
			$userid = $user_data['User_ID']+1-1;
			//if the username is not in db then insert to the table
			
			if($count_row == 1){
				$query = "INSERT INTO student_tbl SET Address='$address', city='$city', DOB='$dob', Gender='$gender', Course_ID='$course_ID',User_ID = $userid";
				
				$result = $this->db->query($query) or die($this->db->error);
				
				return true;
			}
			else{return false;}
			
			
			}
			
			
	/*** for login process ***/
		public function check_login($uname, $upass){		
		$query = "SELECT * FROM user_tbl WHERE username='$uname' AND password = '$upass' AND Status = 'Accepted'";
		
		$result = $this->db->query($query) or die($this->db->error);

		
		$user_data = $result->fetch_array(MYSQLI_ASSOC);
		$count_row = $result->num_rows;
		
		if ($count_row == 1) {
	            $_SESSION['login'] = true; // this login var will use for the session thing
	            $_SESSION['User_ID'] = $user_data['User_ID'];
	            
	             $Visits =  $user_data['Visits'];
	             $query2 ="UPDATE user_tbl SET Visits=$Visits+1 WHERE username='$uname' AND password = '$upass'";
		       $result = $this->db->query($query2) or die($this->db->error);
	            return true;
	        }
			
		else{return false;}
		

	}
	
	
	public function get_fullname($uid){
		$query = "SELECT * FROM user_tbl WHERE User_ID = $uid";
		
		$result = $this->db->query($query) or die($this->db->error);
		
		$user_data = $result->fetch_array(MYSQLI_ASSOC);
		echo $user_data['fname'];
		echo $user_data['lname'];
		$user_data['user_type'];

  


}


	public function get_userType($uid){
		$query = "SELECT * FROM user_tbl WHERE User_ID = $uid";
		
		$result = $this->db->query($query) or die($this->db->error);
		
		$user_data = $result->fetch_array(MYSQLI_ASSOC);
		return $user_data['user_type'];

}




	
	/*** starting the session ***/
	public function get_session(){
	    return $_SESSION['login'];
	    }

	public function user_logout() {
	    $_SESSION['login'] = FALSE;
		unset($_SESSION);
	    session_destroy();
	    }

	    public function postToforumn($User_ID,$blog_title,$blog_content,$Date_Posted,$Time_Posted){

			$query = "INSERT INTO blog_tbl SET Blog_Title='$blog_title',Blog_Content='$blog_content',User_ID = '$User_ID',Time_Posted ='$Time_Posted',Date_Posted = '$Date_Posted'";

			$result = $this->db->query($query) or die($this->db->error);


	    }
	
	public function getPostedForums(){
		            
					$query = "SELECT * FROM blog_tbl";
					$result = $this->db->query($query) or die($this->db->error);
					return $result;
			}
			
				
	public function DisPCom($Blog_ID){
		            
					$query = "SELECT * FROM comments_tbl where Blog_ID = $Blog_ID";
					$result = $this->db->query($query) or die($this->db->error);
					return $result;
			}
				public function Comment($blog_ID,$Comment_Detail,$uid,$Time_Commented,$Date_Commeted){
		            
					$query = "insert into comments_tbl set Blog_ID = '$blog_ID', Comment_Detail = '$Comment_Detail',User_ID = '$uid',time_commented ='0', date_commented='000-00-0'";
					$result = $this->db->query($query) or die($this->db->error);
					return $result;
			}
			public function get_Username($uid){
		$query = "SELECT * FROM user_tbl WHERE User_ID = $uid";
		
		$result = $this->db->query($query) or die($this->db->error);
		
		$user_data = $result->fetch_array(MYSQLI_ASSOC);
		echo $user_data['username'];
		
		$user_data['user_type'];

  


}

public function countFiles($Blog_ID){

	$result = $this->db->query("SELECT COUNT(*) FROM attachments_tbl where Blog_ID= '$Blog_ID'");
	list($numTotal) = $result->fetch_row();
	echo $numTotal;

	
	
}
public function getAllFiles($Blog_ID)
{
    $query = "SELECT * FROM attachments_tbl WHERE Blog_ID ='$Blog_ID'";
    $result = $this->db->query($query) or die($this->db->error);
     return $result;
}
public function countComments($Blog_ID){

	$result = $this->db->query("SELECT COUNT(*) FROM comments_tbl where Blog_ID= '$Blog_ID'");
	list($numTotal) = $result->fetch_row();
	echo $numTotal;

	
	
}
public function getSelectedForum($Blog_ID){
   	$query = "SELECT * FROM blog_tbl where Blog_ID = $Blog_ID";
    $result = $this->db->query($query) or die($this->db->error);
     return $result;
}
		public function Upload($Blog_ID,$location){
		$query = "INSERT INTO attachments_tbl set Blog_ID ='$Blog_ID',location = '$location'"  ;
		
		$result = $this->db->query($query) or die($this->db->error);
		
	
	

}	
			

}