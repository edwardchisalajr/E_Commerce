-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 09, 2018 at 02:30 PM
-- Server version: 5.7.9
-- PHP Version: 5.6.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `e_web`
--
CREATE DATABASE IF NOT EXISTS `e_web` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `e_web`;

-- --------------------------------------------------------

--
-- Table structure for table `attachments_tbl`
--

DROP TABLE IF EXISTS `attachments_tbl`;
CREATE TABLE IF NOT EXISTS `attachments_tbl` (
  `Attachments_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Blog_ID` int(11) NOT NULL,
  `Location` varchar(100) NOT NULL,
  PRIMARY KEY (`Attachments_ID`),
  KEY `Blog_ID` (`Blog_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attachments_tbl`
--

INSERT INTO `attachments_tbl` (`Attachments_ID`, `Blog_ID`, `Location`) VALUES
(1, 0, 'upload/admin.php'),
(2, 6, 'upload/calendar.sql'),
(3, 17, 'upload/full-Forumn.php'),
(4, 16, 'upload/webcam-capture-0.3.10-dist.zip.ueay391.partial'),
(5, 18, 'upload/Custom Organizational Chart 2_backup_0314b.eddx');

-- --------------------------------------------------------

--
-- Table structure for table `blog_tbl`
--

DROP TABLE IF EXISTS `blog_tbl`;
CREATE TABLE IF NOT EXISTS `blog_tbl` (
  `Blog_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Blog_Title` varchar(30) NOT NULL,
  `Blog_Content` varchar(100) NOT NULL,
  `User_ID` int(11) NOT NULL,
  `Date_Posted` date NOT NULL,
  `Time_Posted` time NOT NULL,
  PRIMARY KEY (`Blog_ID`),
  KEY `User_ID` (`User_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blog_tbl`
--

INSERT INTO `blog_tbl` (`Blog_ID`, `Blog_Title`, `Blog_Content`, `User_ID`, `Date_Posted`, `Time_Posted`) VALUES
(17, 'fwefwefw', 'wfefewfwfwf', 19, '2018-10-26', '02:10:03'),
(16, 'I like Learning On this Websit', 'this has been truly an exceprional experience. i was busy with other websites trying  to learn from ', 34, '2018-10-25', '06:10:22'),
(18, 'New Syllabus', 'A new Syllabus has been implemented', 42, '2018-11-09', '01:11:39');

-- --------------------------------------------------------

--
-- Table structure for table `comments_tbl`
--

DROP TABLE IF EXISTS `comments_tbl`;
CREATE TABLE IF NOT EXISTS `comments_tbl` (
  `Comment_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Blog_ID` varchar(30) NOT NULL,
  `Comment_Detail` varchar(100) NOT NULL,
  `User_ID` int(11) NOT NULL,
  `Time_Commented` time NOT NULL,
  `Date_Commented` date NOT NULL,
  PRIMARY KEY (`Comment_ID`),
  KEY `User_ID` (`User_ID`),
  KEY `Blog_ID` (`Blog_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments_tbl`
--

INSERT INTO `comments_tbl` (`Comment_ID`, `Blog_ID`, `Comment_Detail`, `User_ID`, `Time_Commented`, `Date_Commented`) VALUES
(13, '16', '3rrw3rwer', 19, '00:00:00', '0000-00-00'),
(12, '16', 'yeah bro.....this truly is the placde to be', 34, '00:00:00', '0000-00-00'),
(11, '6', 'thisc', 19, '00:00:00', '0000-00-00'),
(10, '3', 'thi  is  bull', 34, '07:10:48', '2018-10-24');

-- --------------------------------------------------------

--
-- Table structure for table `course_tbl`
--

DROP TABLE IF EXISTS `course_tbl`;
CREATE TABLE IF NOT EXISTS `course_tbl` (
  `Course_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Course_Name` varchar(30) NOT NULL,
  `Tutor_ID` int(11) NOT NULL,
  PRIMARY KEY (`Course_ID`),
  KEY `Tutor_ID` (`Tutor_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `event_tbl`
--

DROP TABLE IF EXISTS `event_tbl`;
CREATE TABLE IF NOT EXISTS `event_tbl` (
  `Event_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Event_Title` varchar(30) DEFAULT NULL,
  `Event_Description` varchar(30) DEFAULT NULL,
  `Event_Date` date DEFAULT NULL,
  `Student_ID` int(11) NOT NULL,
  `Tutor_ID` int(11) NOT NULL,
  PRIMARY KEY (`Event_ID`),
  KEY `Tutor_ID` (`Tutor_ID`),
  KEY `Student_ID` (`Student_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `meeting_students_tbl`
--

DROP TABLE IF EXISTS `meeting_students_tbl`;
CREATE TABLE IF NOT EXISTS `meeting_students_tbl` (
  `meeting_students_id` int(10) NOT NULL AUTO_INCREMENT,
  `meeting_id` int(10) DEFAULT NULL,
  `student_id` int(10) DEFAULT NULL,
  `Status` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`meeting_students_id`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `meeting_students_tbl`
--

INSERT INTO `meeting_students_tbl` (`meeting_students_id`, `meeting_id`, `student_id`, `Status`) VALUES
(31, 56, 4, 'pending'),
(30, 56, 5, 'pending'),
(29, 53, 4, 'pending'),
(28, 53, 5, 'pending'),
(27, 51, 4, 'pending'),
(26, 51, 5, 'pending'),
(32, 58, 5, 'Accepted'),
(33, 58, 4, 'pending'),
(34, 59, 6, 'Accepted'),
(35, 61, 6, 'declined'),
(36, 63, 5, 'pending'),
(37, 63, 10, 'Accepted');

-- --------------------------------------------------------

--
-- Table structure for table `meeting_tbl`
--

DROP TABLE IF EXISTS `meeting_tbl`;
CREATE TABLE IF NOT EXISTS `meeting_tbl` (
  `Meeting_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Meeting_Subject` varchar(30) NOT NULL,
  `Meeting_Content` varchar(100) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime NOT NULL,
  `Tutor_ID` int(11) NOT NULL,
  PRIMARY KEY (`Meeting_ID`),
  KEY `Tutor_ID` (`Tutor_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=64 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `meeting_tbl`
--

INSERT INTO `meeting_tbl` (`Meeting_ID`, `Meeting_Subject`, `Meeting_Content`, `start_time`, `end_time`, `Tutor_ID`) VALUES
(55, 'Private Meeting', NULL, '2018-10-06 12:00:00', '2018-10-06 12:30:00', 7),
(56, 'Public Meeting', 'dfdgdfgfgdfgdfgfdf', '2018-10-11 12:00:00', '2018-10-11 12:30:00', 7),
(57, 'Public Meeting', NULL, '2018-11-15 12:00:00', '2018-11-15 12:30:00', 7),
(58, 'Private Meeting', NULL, '2018-11-02 12:00:00', '2018-11-02 12:30:00', 7),
(59, 'Private Meeting', NULL, '2018-11-14 12:00:00', '2018-11-14 12:30:00', 8),
(60, 'Custom', NULL, '2018-11-15 00:00:00', '2018-11-15 00:30:00', 8),
(61, 'kjjj', 'wdwd', '2018-11-06 08:30:00', '2018-11-06 12:30:00', 8),
(63, 'Private Meeting', 'This is the meeting Description', '2018-11-09 09:00:00', '2018-11-09 12:30:00', 9);

-- --------------------------------------------------------

--
-- Table structure for table `message_tbl`
--

DROP TABLE IF EXISTS `message_tbl`;
CREATE TABLE IF NOT EXISTS `message_tbl` (
  `Messege_ID` int(11) NOT NULL AUTO_INCREMENT,
  `MesseageText` varchar(500) NOT NULL,
  `SentFrom` int(11) NOT NULL,
  `Student_ID` int(11) NOT NULL,
  `Tutor_ID` int(11) NOT NULL,
  `DateSent` date NOT NULL,
  PRIMARY KEY (`Messege_ID`),
  KEY `Tutor_ID` (`Tutor_ID`),
  KEY `Student_ID` (`Student_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=80 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `message_tbl`
--

INSERT INTO `message_tbl` (`Messege_ID`, `MesseageText`, `SentFrom`, `Student_ID`, `Tutor_ID`, `DateSent`) VALUES
(79, 'qsqs', 19, 3, 6, '2018-11-09'),
(77, 'wdwd', 42, 5, 9, '2018-11-09'),
(75, 'Glad to have you on Board', 42, 10, 9, '2018-11-09'),
(74, 'Im your new Student', 41, 10, 9, '2018-11-09'),
(78, 'wddw', 42, 11, 9, '2018-11-09'),
(72, '111111', 38, 6, 8, '2018-11-06'),
(71, 'w', 38, 6, 8, '2018-11-06'),
(70, '111', 36, 6, 8, '2018-11-06'),
(69, 'tttt', 36, 6, 8, '2018-11-06'),
(68, 'iiiii', 36, 6, 8, '2018-11-06'),
(67, 'yyyyy', 36, 6, 8, '2018-11-06');

-- --------------------------------------------------------

--
-- Table structure for table `student_tbl`
--

DROP TABLE IF EXISTS `student_tbl`;
CREATE TABLE IF NOT EXISTS `student_tbl` (
  `Student_ID` int(11) NOT NULL AUTO_INCREMENT,
  `User_ID` int(11) NOT NULL,
  `Address` varchar(30) DEFAULT NULL,
  `city` varchar(30) DEFAULT NULL,
  `DOB` date DEFAULT NULL,
  `Gender` varchar(30) DEFAULT NULL,
  `Course_ID` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`Student_ID`),
  KEY `User_ID` (`User_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_tbl`
--

INSERT INTO `student_tbl` (`Student_ID`, `User_ID`, `Address`, `city`, `DOB`, `Gender`, `Course_ID`) VALUES
(3, 19, '1', '1', '2018-09-12', 'Male', '1'),
(4, 28, 'wdwdwd', 'dwdwdw', '2018-09-19', 'Male', '1'),
(5, 35, 'r', 'r', '2018-09-23', 'Male', '2'),
(6, 36, 'wd', 'wd', '2018-10-25', 'Male', '1'),
(7, 37, 'g', 'g', '2018-10-26', 'Male', '1'),
(8, 39, 'Malawi', 'Blantyre', '1994-11-09', 'Male', '1'),
(9, 40, 'Malawi', 'Blantyre', '1994-11-09', 'Male', '1'),
(10, 41, 'Malawi', 'Blantyre', '1994-11-09', 'Male', '1'),
(11, 43, 'Malawi', 'Lilongwe', '2018-11-09', 'Male', '1'),
(12, 45, 'imnoinmd', 'oienowemnfk', '2018-11-09', 'Male', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tutor_student_tbl`
--

DROP TABLE IF EXISTS `tutor_student_tbl`;
CREATE TABLE IF NOT EXISTS `tutor_student_tbl` (
  `Tutor_Student_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Tutor_ID` int(11) NOT NULL,
  `Student_id` int(11) NOT NULL,
  PRIMARY KEY (`Tutor_Student_ID`),
  KEY `Tutor_ID` (`Tutor_ID`),
  KEY `Student_id` (`Student_id`)
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tutor_student_tbl`
--

INSERT INTO `tutor_student_tbl` (`Tutor_Student_ID`, `Tutor_ID`, `Student_id`) VALUES
(39, 6, 7),
(36, 6, 4),
(35, 6, 3),
(37, 9, 5),
(38, 8, 6),
(40, 9, 10);

-- --------------------------------------------------------

--
-- Table structure for table `tutor_tbl`
--

DROP TABLE IF EXISTS `tutor_tbl`;
CREATE TABLE IF NOT EXISTS `tutor_tbl` (
  `Tutor_id` int(11) NOT NULL AUTO_INCREMENT,
  `User_ID` int(11) NOT NULL,
  `Qualification` varchar(30) NOT NULL,
  PRIMARY KEY (`Tutor_id`),
  KEY `User_ID` (`User_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tutor_tbl`
--

INSERT INTO `tutor_tbl` (`Tutor_id`, `User_ID`, `Qualification`) VALUES
(6, 33, 'wqdqwd'),
(5, 32, 'wdq '),
(4, 31, ''),
(7, 34, 'q'),
(8, 38, 'DEGREE'),
(9, 42, 'Degree'),
(10, 44, 'Masters Degree'),
(11, 46, 'edwed');

-- --------------------------------------------------------

--
-- Table structure for table `user_tbl`
--

DROP TABLE IF EXISTS `user_tbl`;
CREATE TABLE IF NOT EXISTS `user_tbl` (
  `User_ID` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(30) NOT NULL,
  `lname` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `user_type` varchar(30) NOT NULL,
  `Visits` int(11) NOT NULL,
  `Status` varchar(30) NOT NULL,
  PRIMARY KEY (`User_ID`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=47 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_tbl`
--

INSERT INTO `user_tbl` (`User_ID`, `fname`, `lname`, `email`, `username`, `password`, `user_type`, `Visits`, `Status`) VALUES
(19, '1', '1', '1@1', '1', '1', 'Student', 6, 'Declined'),
(28, 'New', 'User', 'NewUser@user.com', 'New User', '1234', 'Student', 1, ''),
(31, 'yu', 'hu', 'ui$@dw.com', 'ui', 'wdwd', 'Tutor', 0, ''),
(1, 'Admin', '', '', 'Admin', 'Admin', 'Admin', 26, 'Accepted'),
(32, 'qwq', 'wdwd', 'wdfwefw@wd.com', 'ewqf', 'wdw', 'Tutor', 0, ''),
(33, 'wqws', 'wwdwd', 'wddwd@wdew.com', 'wdwd', 'dqwd', 'Tutor', 3, ''),
(34, 'q', 'q', 'q@q.com', 'q', 'q', 'Tutor', 1, ''),
(35, 'George', 'Nyondo', 'georgennd@gmail.com', 'Metric', '1234', 'Student', 3, ''),
(36, 'wd', 'dw', 'dw@1q', 'wd', 'wd', 'Student', 7, 'Accepted'),
(37, 'g', 'g', 'g@wfe', 'g', 'gg', 'Student', 0, ''),
(41, 'Patience', 'Mwale', 'Mwale@d.com', 'PatienceM', '1234', 'Student', 11, 'Accepted'),
(42, 'John', 'Mwale', 'Mwale@d.com', 'JohnM', '1234', 'Tutor', 6, ''),
(43, 'Nelson', 'Philip', 'Philip@gmail.com', 'NelsonP', '1234', 'Student', 0, ''),
(44, 'Joana', 'Niel', 'Niel@j.com', 'JoanaN', '1234', 'Tutor', 0, ''),
(45, '12121', 'yhiunnj', 'inijnuijn@imoknmi', 'oimoinjnui', '123', 'Student', 1, 'Accepted'),
(46, 'wqdqwd', 'ewedf', 'edw@qw', 'ewe', '123', 'Tutor', 1, 'Accepted');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
