<?php

include_once 'db_config.php';


class Tutor {
		protected $db;
			public function __construct(){
					$this->db = new DB_con();
					$this->db = $this->db->ret_obj();
			}
			public function reg_user($uname, $Firstname, $Lastname, $uemail,$upass){
			$query = "SELECT * FROM user_tbl WHERE username='$uname' AND password='$upass'";
			
			$result = $this->db->query($query) or die($this->db->error);
			
			$count_row = $result->num_rows;
			
			
			if($count_row == 0){
				$query = "INSERT INTO user_tbl SET username='$uname', password='$upass', fname='$Firstname', email='$uemail', lname='$Lastname', user_type='Tutor'";
				
				$result = $this->db->query($query) or die($this->db->error);
				
				return true;
			}
			else{return false;
				}
			}
			 public function reg_tutor($uname,$upass,$qualification){
			$query = "SELECT * FROM user_tbl WHERE username='$uname' AND password = '$upass'";
			
			$result = $this->db->query($query) or die($this->db->error);
			
			$count_row = $result->num_rows;
			$user_data = $result->fetch_array(MYSQLI_ASSOC);
			$userid = $user_data['User_ID']+1-1;
			
			if($count_row == 1){
				$query = "INSERT INTO tutor_tbl SET User_ID = '$userid',Qualification='$qualification'";
				
				$result = $this->db->query($query) or die($this->db->error);
				
				return true;
			}
			else{return false;}
			
			
			
			}
			

			public function getStudentDetails($User_ID){
					$query = "SELECT * FROM student_tbl WHERE User_ID = $User_ID";
					$result = $this->db->query($query) or die($this->db->error);
					return $result;
			}
			
			public function getTutorDetails($User_ID){
					$query = "SELECT * FROM tutor_tbl WHERE User_ID = $User_ID";
					$result = $this->db->query($query) or die($this->db->error);
					return $result;
			}
			
			
			public function getStudentUserID($StudentID){
					$query = "SELECT * FROM student_tbl join user_tbl on user_tbl.User_ID = student_tbl.User_ID WHERE student_tbl.Student_ID = '$StudentID'";
					$result = $this->db->query($query) or die($this->db->error);
					return $result;
			}

			
			
			public function getStudents($Tutor_ID){
					$query = "select user_tbl.User_ID,user_tbl.fname,user_tbl.lname,user_tbl.email from student_tbl
								  JOIN user_tbl on user_tbl.User_ID = student_tbl.User_ID
								  join tutor_student_tbl on tutor_student_tbl.Student_id = student_tbl.Student_ID
								  join tutor_tbl on tutor_tbl.Tutor_id = tutor_student_tbl.Tutor_ID
								  where tutor_tbl.Tutor_id = $Tutor_ID;";
					$result = $this->db->query($query) or die($this->db->error);
					return $result;
			}

			public function getTutors(){
					$query = "SELECT * FROM user_tbl WHERE user_type = 'Tutor'";
					$result = $this->db->query($query) or die($this->db->error);
					return $result;
			}
			
			public function getMessages($Tutor_ID,$StudentID){
					$query = "SELECT * FROM message_tbl WHERE Tutor_ID = '$Tutor_ID' AND Student_ID = '$StudentID' ORDER BY Messege_ID ASC";
					$result = $this->db->query($query) or die($this->db->error);
					return $result;
			}
			
			
			public function sendMessage($Tutor_ID,$StudentID,$Message){
					$User_ID = $_SESSION['User_ID'];
					$Date = date("Y-m-d");
					$query = "INSERT INTO message_tbl SET MesseageText = '$Message',SentFrom = '$User_ID',Student_ID = '$StudentID', Tutor_ID='$Tutor_ID',DateSent = '$Date'";
					$result = $this->db->query($query) or die($this->db->error);
					return true;
			}

			public function AssignStudentsToMeetings($meeting_id,$Student_id){
					$query = "INSERT INTO meeting_students_tbl SET meeting_id ='$meeting_id',student_id='$Student_id',status='pending'";
					$result = $this->db->query($query) or die($this->db->error);
					if($result){
						echo "Students Assigned To meeting";
						return true;
					}
					echo "An Error Occured";
					return false;
			}	
			
	
			
			
			
}
?>