# Jquery-Calendar-using-PHP-and-MySQL
#Just follow the steps
## Step1 : Import the calendar.sql file in your database
## Step2 : Set the database configurations in config.phpfile
## Step5 : open this file to view calendar "html-pop-up-calendar-view.html"

# Full step by step implementaion of jquery calendar using php and Mysql on following page
## http://phpclicks.com/jquery-full-calendar-integration-with-bootstrap-phpmysql/
