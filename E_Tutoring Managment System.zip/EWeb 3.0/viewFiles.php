`<?php
session_start();
?>
<?php // require_once('connect.php'); ?>
<?

 include_once 'include/class.user.php';
   $user = new User();
   
      $uid = $_SESSION['User_ID'];
    $Blog_ID =$_GET['Blog_ID'];


    if (!$user->get_session()){
       header("location:login.php");
    }

    if (isset($_GET['q'])){
        $user->user_logout();
        header("location:login.php");
        

    }
?>
<html>
     <titlle></title>

     <head>



<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Homepage</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ETUTORING</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/user.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="css/dashstyle.css">

    <!--  -->
<link href="css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN"
        crossorigin="anonymous">

<link href="css/displaycss.css" rel="stylesheet" id="bootstrap-css">
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link href="css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN"
        crossorigin="anonymous">
        
<script src="js/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
 <script src="js/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
        crossorigin="anonymous"></script>
<script src="js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy"
        crossorigin="anonymous"></script>
<nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container">
            <div class="navbar-header"><a class="navbar-brand navbar-link" href="StudentHome.php"><i class="fa fa-fw fa-user"></i> Student Account</a>
                
                
            
                <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            </div>



            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="nav navbar-nav navbar-right">
                   <li class="">
                        <a href="StudentHome.php"><i class="fa fa-fw fa-home fa-2x"></i> Dashboard</a>
                    </li>
                    <li>
                        <a href="StudentMessage.php"><i class="fa fa-fw fa-wechat fa-2x"></i> Messages</a>
                    </li>
                    

                    <li>
                        <a href="ViewMeetings.php"><i class="fa fa-fw fa-calendar fa-2x"></i> Meetings</a>
                    </li>

                    <li>
                        <a href="Forumn.php"><i class="fa fa-fw fa-twitter fa-2x"></i> Blog</a>
                    </li>

                     <li role="presentation"><a href="logout.php?q=logout"><i class="fa fa-fw fa-undo fa-2x"></i>Logout</a></li>

                    
                    
                </ul>
            </div>
        </div>
    </nav>
<br><br><br><br>
<body>


<style type="text/css">


h3{
background-color:#CCCCCC;
text-align:center;

border:1px green solid;
}

</style>
</body>



  <?php
//getting id from url

//selecting data associated with this particular id
  


      

       
        

// echo "<table><tr><th>ID</th><th>Name</th><th>E-mail</th><th>Gender</th><th>Birth Date</th><th>Website</th><th>Address</th><th>Province</th><th>Zip Code</th><th>City</th><th>Join Date</th><th>Annual Basic Pay</th></tr>";

?>
<hr />
<br/><br/> 
<center>
<div id="content">
<div class="widget stacked widget-table action-table">
                <div class="container"> 
                            <div class="table-responsive">      
                            <table class="table">
        <div class="widget-header">
          <i class="icon-th-list"></i>
          <h3>Download Files</h3>
        </div> <!-- /widget-header -->
        
        <div class="widget-content">
                    <div class="container"> 
                            <div class="table-responsive">      
                            <table class="table">
          <form action="#" method="post">
          <table class="table table-striped table-bordered">
            <thead>
              <tr>
                <th>File ID</th>
                <th>File Name</th>
                <th>Downlod-Link</th>
               
                <th ></th>
              </tr>
            </thead>
            <tbody >
              <tr>
              <?
            $Files = $user->getAllFiles($Blog_ID);
              while( $row=mysqli_fetch_array($Files)){
        
              ?>
                <td><?echo $row['Attachments_ID']?></td>
                <td><?echo $row['Blog_ID']?></td>
                <td><a title='Click here to download  file.' 
         href='download.php?Blog_ID=<?$row['Location']?>'><?echo $row['Location']?></a></td>
                
               
                
                                    
              
           
              </tr>
              <?
              }
              ?>
              
              
              </tbody>
            </table>
            <tr>
<br /><br />


</form>
</div></center>
<script>
      function Comment() {
        var form = document.com;
        if (form.Comment_Detail.value == "") {
          alert("To Comment Please Write Comment First !!.");
          return false;

          }

      }</script>
</html>
  