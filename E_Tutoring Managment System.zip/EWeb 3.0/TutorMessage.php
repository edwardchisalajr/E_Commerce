<?
session_start();
include 'include/class.Tutor.php';
$Tutor = new Tutor();

if(isset($_POST['Message'])){
	$SendMessage = $Tutor->sendMessage($_SESSION['Tutor_ID'],$_GET['StudentID'],$_POST['Message']);
	if ($SendMessage) {
	      echo 'Message Sent';
	        
	    }
		else {
	       
	        echo 'Wrong username or password';
	    }
	}
?>


<!------ Include the above in your HEAD tag ---------->

<link href="css/style.css" rel="stylesheet" id="bootstrap-css">
<html>
<head>
<title>Tutor Messaging</title>
<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css"> 
  <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap-theme.css"> 
  <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap-theme.min.css"> 

    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">

</head>
<body>
<?
include 'Tutorlinks.php';
?>
<br><br><br><br>
<div class="container">
<h3 class=" text-center"  > <i class="fa fa-twitter"></i> Messaging</h3>
<div class="messaging">
      <div class="inbox_msg">
        <div class="inbox_people">
          <div class="headind_srch">
            <div class="recent_heading">
              <h4>Your Students</h4>
            </div>
			
            <div class="srch_bar">
              <div class="stylish-input-group">
                 
                <span class="input-group-addon">
                <button type="button"> <i class="fa fa-search" aria-hidden="true"></i> </button>
                </span> </div>
            </div>
          </div>
          <div class="inbox_chat">
		  <?
							$Students = $Tutor->getStudents($_SESSION['Tutor_ID']);
							while( $row=mysqli_fetch_array($Students)){
							$Studentdetails = $Tutor->getStudentDetails($row['User_ID']);
							$studentRow=mysqli_fetch_array($Studentdetails);
							$Student_id = $studentRow['Student_ID'];
							
							
							?>
								<div class="chat_list active_chat">
								  <div class="chat_people">
									<div class="chat_img"> <img src="assets/img/user-profile.png" alt="sunil"> </div>
									<div class="chat_ib">
									  <h5><a href="TutorMessage.php?StudentID=<?php echo $Student_id;?> "><?php echo $row['fname']; ?> <?php echo $row['lname']; ?> <?php echo $row['email']; ?></a>
								 
									</div>
								  </div>
								</div>
								 
							<?
							}
		?>
          </div>
        </div>
		<?
		if(isset($_GET['StudentID'])){
			?>
        <div class="mesgs">
          <div class="msg_history">
			<?
			  
			  $Message = $Tutor->getMessages($_SESSION['Tutor_ID'],$_GET['StudentID']);
			  $StudentUserID = $Tutor->getStudentUserID($_GET['StudentID']);
			  $Studentrow=mysqli_fetch_array($StudentUserID);
			  $StudentUserID = $Studentrow["User_ID"];
			  while( $row=mysqli_fetch_array($Message)){
				  if($row['SentFrom']==$StudentUserID){
					  ?>
						<div class="incoming_msg">
						 <div class="incoming_msg_img"> <img src="assets/img/user-profile.png" alt="sunil"> </div>
						  <div class="received_msg">
							<div class="received_withd_msg">
							  <p><? echo $row['MesseageText']?></p> 
							  </div>
						  </div>
						</div>
					  <?
				  }
				  else{
					  ?>
					    <div class="outgoing_msg">
						<div class="sent_msg">
							<p><? echo $row['MesseageText']?></p>
							</div>
						</div>
					  <?
					  
				  }
			  }
              ?>
          </div>
          <div class="type_msg">
            <div class="input_msg_write">
			<form action="#" method="post">
              <input type="text" name  = "Message" class="write_msg" placeholder="Type a message" />
              <input type="submit" name="submit" value="Submit" />
			  </form>
            </div>
			
          </div>
        </div>
      </div>
		<?}
      ?>
      <p class="text-center top_spac"><a target="_blank" href="#"><? echo $_SESSION['Tutor_ID'];?></a></p>
      
    </div></div>
		<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.min.js"></script>
    </body>
    </html>