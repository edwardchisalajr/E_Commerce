<<?
include 'include/class.admin.php';
$admin = new Admin();
$Tutors = $admin->countTutors();
$TutorRows = mysqli_fetch_array($Tutors);
$TotalTutors = $TutorRows['TotalTutors'];
$Users = $admin->countUsers();
$UserRows = mysqli_fetch_array($Users);
$TotalUsers = $UserRows['TotalUsers'];
$Students = $admin->countStudents();
$StudentRows = mysqli_fetch_array($Students);
$TotalStudents = $StudentRows['TotalStudents'];
$Admins = $admin->countAdmins();
$AdminRows = mysqli_fetch_array($Admins);
$TotalAdmins = $AdminRows['TotalAdmins'];

$TutorPerc = $TotalTutors/$TotalUsers*100;

$StudentPerc = $TotalStudents/$TotalUsers*100;

$AdminPerc = $TotalAdmins/$TotalUsers*100;
 

?>
<head>
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Homepage</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ETUTORING</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/user.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="css/dashstyle.css">

    <!--  -->
<link href="css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN"
        crossorigin="anonymous">

<link href="css/displaycss.css" rel="stylesheet" id="bootstrap-css">
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link href="css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN"
        crossorigin="anonymous">
        
<script src="js/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
 <script src="js/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
        crossorigin="anonymous"></script>
<script src="js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy"
        crossorigin="anonymous"></script>
<script>
window.onload = function () {

var chart = new CanvasJS.Chart("chartContainer", {
  exportEnabled: true,
  animationEnabled: true,
  title:{
    text: "Users in the System"
  },
  legend:{
    cursor: "pointer",
    itemclick: explodePie
  },
  data: [{
    type: "pie",

    showInLegend: true,
    toolTipContent: "{name}: <strong>{y}%</strong>",
    indexLabel: "{name} - {y}%",
    dataPoints: [
      { y: <?echo $TutorPerc;?>, name: "Tutors", exploded: true },
      { y: <?echo $StudentPerc;?>, name: "Students", exploded: true },
      { y: <?echo $AdminPerc;?>, name: "Admins", exploded: true  } 
    ]
  }]
});
chart.render();
}

function explodePie (e) {
  if(typeof (e.dataSeries.dataPoints[e.dataPointIndex].exploded) === "undefined" || !e.dataSeries.dataPoints[e.dataPointIndex].exploded) {
    e.dataSeries.dataPoints[e.dataPointIndex].exploded = true;
  } else {
    e.dataSeries.dataPoints[e.dataPointIndex].exploded = false;
  }
  e.chart.render();

}
</script>
</head>

<body>
<nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container">
            <div class="navbar-header"><a class="navbar-brand navbar-link" href="AdminDash.php"><i class="fa fa-fw fa-user "></i> Admin Account</a>
                
                
            
                <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            </div>



            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="nav navbar-nav navbar-right">
                   <li class="">
                        <a href="AdminDash.php"><i class="fa fa-fw fa-home fa-2x"></i> Dashboard</a>
                    </li>
                    <li>
                        <a href="AssignStudents.php"><i class="fa fa-users fa-fw fa-2x"></i> Assing student</a>
                    </li>
					
					<li>
                        <a href="AcceptStudents.php"><i class="fa fa-users fa-fw fa-2x"></i> Accept student</a>
                    </li>
                    <li>
                        <a href="admin.php"><i class="fa fa-fw fa-user fa-2x"></i>Add tutor</a>
                    </li>
                    

                    

                    <li>
                        <a href="bootstrap-grid.html"><i class="fa fa-fw fa-twitter fa-2x"></i> Blog</a>
                    </li>
                    <li role="presentation"><a href="logout.php?q=logout"><i class="fa fa-fw fa-undo fa-2x"></i>Logout</a></li>


                    
                    
                </ul>
            </div>
        </div>
    </nav>
    <br><br><br><br>

<div class="container bootstrap snippet">
  <div class="row">
    <div class="col-lg-3">
      <div class="circle-tile ">
        <a href="#"><div class="circle-tile-heading dark-blue"><i class="fa fa-users fa-fw fa-3x"></i></div></a>
        <div class="circle-tile-content dark-blue">
          <div class="circle-tile-description text-faded">All Users</div>
          <div class="circle-tile-number text-faded "><?echo $TotalUsers;?></div>
          <a class="circle-tile-footer" href="#">More Info<i class="fa fa-chevron-circle-right"></i></a>
        </div>
      </div>
    </div>
     
    <div class="col-lg-3">
      <div class="circle-tile ">
        <a href="#"><div class="circle-tile-heading blue"><i class="fa fa-users fa-fw fa-3x"></i></div></a>
        <div class="circle-tile-content blue">
          <div class="circle-tile-description text-faded"> Tutors </div>
          <div class="circle-tile-number text-faded "><?echo $TotalTutors;?></div>
          <a class="circle-tile-footer" href="TutorDetail.php">More Info<i class="fa fa-chevron-circle-right"></i></a>
        </div>
      </div>
    </div>

<div class="col-lg-3">
      <div class="circle-tile ">
        <a href="#"><div class="circle-tile-heading red"><i class="fa fa-users fa-fw fa-3x"></i></div></a>
        <div class="circle-tile-content red">
          <div class="circle-tile-description text-faded"> Students </div>
          <div class="circle-tile-number text-faded "><?echo $TotalStudents;?></div>
          <a class="circle-tile-footer" href="StudentDetail.php">More Info<i class="fa fa-chevron-circle-right"></i></a>
        </div>
      </div>
      </div>

  <div class="col-lg-3">
      <div class="circle-tile ">
        <a href="#"><div class="circle-tile-heading green"><i class="fa fa-users fa-fw fa-3x"></i></div></a>
        <div class="circle-tile-content green">
          <div class="circle-tile-description text-faded"> Admins </div>
          <div class="circle-tile-number text-faded "><?echo $TotalAdmins;?></div>
          <a class="circle-tile-footer" href="#">Administrator<i class="fa fa-chevron-circle-right"></i></a>
        </div>
      </div>






</div>  
  
</div>

<br><br>

<div id="chartContainer" style="height: 370px; max-width: 920px; margin: 0px auto;"></div>

<br><br>
    <script src="js/canvasjs.min.js"></script>
</div>
 </body>