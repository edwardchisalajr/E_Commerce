<?
include 'include/class.admin.php';
$admin = new Admin();
$CountAllTutorStudents = $admin->CountTutorWithStudents();
$CountAllTutorStudentsRows = mysqli_fetch_array($CountAllTutorStudents);
$CountAllTutorStudents = $CountAllTutorStudentsRows['Tutors'];

$CountAllTutorsWithoutStudents = $admin->CountTutorWithoutStudents();
$CountAllTutorsWithoutStudentsRows = mysqli_fetch_array($CountAllTutorsWithoutStudents);
$CountAllTutorsWithoutStudents = $CountAllTutorsWithoutStudentsRows['Tutors'];

$TotalTutors = $CountAllTutorStudents+$CountAllTutorsWithoutStudents;
$WithTutors = $CountAllTutorStudents/$TotalTutors*100;

$WithoutTutors = $CountAllTutorsWithoutStudents/$TotalTutors*100;


?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Homepage</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ETUTORING</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/user.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="css/dashstyle.css">

    <!--  -->
<link href="css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN"
        crossorigin="anonymous">

<link href="css/displaycss.css" rel="stylesheet" id="bootstrap-css">
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link href="css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN"
        crossorigin="anonymous">
<script>
window.onload = function () {

var chart = new CanvasJS.Chart("chartContainer", {
	exportEnabled: true,
	animationEnabled: true,
	theme: "light2", // "light1", "light2", "dark1", "dark2"
	title:{
		text: "Distribution of Assigned Students"
	},
	axisY: {
		title: "Students"
	},
	data: [{        
		type: "column",  
		showInLegend: true, 
		legendMarkerColor: "grey",
		legendText: "Tutors",
		dataPoints: [
		<?
							$AllTutorStudents = $admin->CountAllTutorStudents();
							while( $row=mysqli_fetch_array($AllTutorStudents)){
				
		?>
			{ y: <?php echo $row['AssignedStudents']; ?>, label: "<?php echo $row['fname'] ." " .$row['lname']?>" },
		
			 	<?
							}
			?>
		]
	}]
});
chart.render();
var chart = new CanvasJS.Chart("piechartContainer", {
	exportEnabled: true,
	animationEnabled: true,
	title:{
		text: "Tutor Assigning Graph"
	},
	legend:{
		cursor: "pointer",
		itemclick: explodePie
	},
	data: [{
		type: "pie",

		showInLegend: true,
		toolTipContent: "{name}: <strong>{y}%</strong>",
		indexLabel: "{name} - {y}%",
		dataPoints: [
			{ y: <?echo $WithTutors?>, name: "Tutors With Students", exploded: true },
			{ y: <?echo $WithoutTutors?>, name: "Tutors Without Students", exploded: true  }

		]
	}]
});
chart.render();
}

function explodePie (e) {
	if(typeof (e.dataSeries.dataPoints[e.dataPointIndex].exploded) === "undefined" || !e.dataSeries.dataPoints[e.dataPointIndex].exploded) {
		e.dataSeries.dataPoints[e.dataPointIndex].exploded = true;
	} else {
		e.dataSeries.dataPoints[e.dataPointIndex].exploded = false;
	}
	e.chart.render();
}
</script>
</head>

<nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container">
            <div class="navbar-header"><a class="navbar-brand navbar-link" href="AdminDash.php"><i class="fa fa-fw fa-user"></i> Admin Account</a>
                
                
            
                <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            </div>



            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="nav navbar-nav navbar-right">
                    <li class="">
                        <a href="AdminDash.php"><i class="fa fa-fw fa-home fa-2x"></i> Dashboard</a>
                    </li>
                    <li>
                        <a href="StudentMessage.php"><i class="fa fa-users fa-fw fa-2x"></i> Assing student</a>
                    </li>
                    

                    

                    <li>
                        <a href="bootstrap-grid.html"><i class="fa fa-fw fa-twitter fa-2x"></i> Blog</a>
                    </li>

                    
                    
                </ul>
            </div>
        </div>
    </nav>
<br><br><br><br><br><br>
<div class="container bootstrap snippet">
 					<table class="table table-striped table-bordered">
						<thead>
							<tr>
								<th>First Name</th>
								<th>Last Name</th> 
								<th>Email</th> 
								<th>Qualification</th> 
								<th>Assigned Students</th> 
								
							</tr>
						</thead>
						<tbody >
							<tr>
							<?
							$Tutors = $admin->getTutors();
							while( $row=mysqli_fetch_array($Tutors)){
							$UserID = $row['User_ID'];
							?>
								<td><?php echo $row['fname']; ?></td>
								<td><?php echo $row['lname']; ?></td> 
								<td><?php echo $row['email']; ?></td>
								<td><?php $Qualification = $admin->getTutorDetails($UserID); 
								$QualificationRow = mysqli_fetch_array($Qualification);
								echo $QualificationRow['Qualification']; ?></td>
								
								<td><?php  
								 $admin->CountTutorsStudents($UserID);
								

								?></td>
								<td>  <a button class="btn btn-danger" title="Click here to View." href = "TutorStats.php?UserID=<?echo $UserID?>">TutorStats </a></td>
								
							</tr>
							<?
							}
							?>
							
							
							</tbody>
						</table>
</div> 
 
  
</div>



</div>
<br>

<div class="container bootstrap snippet">
<div id="chartContainer" style="height: 370px; max-width: 920px; margin: 0px auto;"></div>
		<script src="js/canvasjs.min.js"></script>
</div> 
<br><br>
<div class="container bootstrap snippet">
<div id="piechartContainer" style="height: 370px; max-width: 920px; margin: 0px auto;"></div>
		<script src="js/canvasjs.min.js"></script>
</div> 
<br>
<br>


 