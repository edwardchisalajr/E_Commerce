<?
include 'include/class.admin.php';
$admin = new Admin();
$CountAllTutorStudents = $admin->CountTutorWithStudents();
$CountAllTutorStudentsRows = mysqli_fetch_array($CountAllTutorStudents);
$CountAllTutorStudents = $CountAllTutorStudentsRows['Tutors'];

$CountAllTutorsWithoutStudents = $admin->CountTutorWithoutStudents();
$CountAllTutorsWithoutStudentsRows = mysqli_fetch_array($CountAllTutorsWithoutStudents);
$CountAllTutorsWithoutStudents = $CountAllTutorsWithoutStudentsRows['Tutors'];

$TotalTutors = $CountAllTutorStudents+$CountAllTutorsWithoutStudents;
$WithTutors = $CountAllTutorStudents/$TotalTutors*100;

$WithoutTutors = $CountAllTutorsWithoutStudents/$TotalTutors*100;


?>
<link href="css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->


<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="css/dashstyle.css">
<script>
window.onload = function () {

var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,
	theme: "light2", // "light1", "light2", "dark1", "dark2"
	title:{
		text: "Distribution of Assigned Students"
	},
	axisY: {
		title: "Students"
	},
	data: [{        
		type: "column",  
		showInLegend: true, 
		legendMarkerColor: "grey",
		legendText: "Tutors",
		dataPoints: [
		<?
							$AllTutorStudents = $admin->CountAllTutorStudents();
							while( $row=mysqli_fetch_array($AllTutorStudents)){
				
		?>
			{ y: <?php echo $row['AssignedStudents']; ?>, label: "<?php echo $row['fname'] ." " .$row['lname']?>" },
		
			 	<?
							}
			?>
		]
	}]
});
chart.render();
var chart = new CanvasJS.Chart("piechartContainer", {
	exportEnabled: true,
	animationEnabled: true,
	title:{
		text: "Tutor Assigning Graph"
	},
	legend:{
		cursor: "pointer",
		itemclick: explodePie
	},
	data: [{
		type: "pie",

		showInLegend: true,
		toolTipContent: "{name}: <strong>{y}%</strong>",
		indexLabel: "{name} - {y}%",
		dataPoints: [
			{ y: <?echo $WithTutors?>, name: "Tutors With Students", exploded: true },
			{ y: <?echo $WithoutTutors?>, name: "Tutors Without Students", exploded: true  }

		]
	}]
});
chart.render();


function explodePie (e) {
	if(typeof (e.dataSeries.dataPoints[e.dataPointIndex].exploded) === "undefined" || !e.dataSeries.dataPoints[e.dataPointIndex].exploded) {
		e.dataSeries.dataPoints[e.dataPointIndex].exploded = true;
	} else {
		e.dataSeries.dataPoints[e.dataPointIndex].exploded = false;
	}
	e.chart.render();
}
</script>
<div class="container bootstrap snippet">
<div id="chartContainer" style="height: 370px; max-width: 920px; margin: 0px auto;"></div>
		<script src="js/canvasjs.min.js"></script>
</div> 
<div class="container bootstrap snippet">
<div id="piechartContainer" style="height: 370px; max-width: 920px; margin: 0px auto;"></div>
		<script src="js/canvasjs.min.js"></script>
</div> 

<div class="container bootstrap snippet">
 					<table class="table table-striped table-bordered">
						<thead>
							<tr>
								<th>First Name</th>
								<th>Last Name</th> 
								<th>Email</th> 
								<th>Assigned Students</th> 
								
							</tr>
						</thead>
						<tbody >
							<tr>
							<?
							$Tutors = $admin->getTutors();
							while( $row=mysqli_fetch_array($Tutors)){
				
							?>
								<td><?php echo $row['fname']; ?></td>
								<td><?php echo $row['lname']; ?></td> 
								<td><?php echo $row['email']; ?></td>
								
								<td><?php $UserID = $row['User_ID']; 
								 $admin->CountTutorsStudents($UserID);
								

								?></td>
								<td><a href = "TutorStats.php?UserID=<?echo $UserID?>">TutorStats</a></td>
								
							</tr>
							<?
							}
							?>
							
							
							</tbody>
						</table>
</div> 
 
  
</div>



</div>
 