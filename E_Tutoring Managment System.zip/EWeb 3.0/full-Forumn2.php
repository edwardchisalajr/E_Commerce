<?php
session_start();
?>
<?php // require_once('connect.php'); ?>
<?

 include_once 'include/class.user.php';
   $user = new User();
    $uid = $_SESSION['User_ID'];

    if (!$user->get_session()){
       header("location:login.php");
    }

    if (isset($_GET['q'])){
        $user->user_logout();
        header("location:login.php");
        

    }
    $Blog_ID = $_GET['Blog_ID'];
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Homepage</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ETUTORING</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/user.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="css/dashstyle.css">

    <!--  -->
<link href="css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN"
        crossorigin="anonymous">

<link href="css/displaycss.css" rel="stylesheet" id="bootstrap-css">
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link href="css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN"
        crossorigin="anonymous">
        
<script src="js/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
 <script src="js/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
        crossorigin="anonymous"></script>
<script src="js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy"
        crossorigin="anonymous"></script>
<body>
<nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container">
            <div class="navbar-header"><a class="navbar-brand navbar-link" href="StudentHome.php"><i class="fa fa-fw fa-user"></i> Student Account</a>
                
                
            
                <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            </div>



            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="nav navbar-nav navbar-right">
                   <li class="">
                        <a href="StudentHome.php"><i class="fa fa-fw fa-home fa-2x"></i> Dashboard</a>
                    </li>
                    <li>
                        <a href="StudentMessage.php"><i class="fa fa-fw fa-wechat fa-2x"></i> Messages</a>
                    </li>
                    

                    <li>
                        <a href="ViewMeetings.php"><i class="fa fa-fw fa-calendar fa-2x"></i> Meetings</a>
                    </li>

                    <li>
                        <a href="Forumn.php"><i class="fa fa-fw fa-twitter fa-2x"></i> Blog</a>
                    </li>

                     <li role="presentation"><a href="logout.php?q=logout"><i class="fa fa-fw fa-undo fa-2x"></i>Logout</a></li>

                    
                    
                </ul>
            </div>
        </div>
    </nav>
<br><br><br><br>
</body>

  <form action="" method="post" enctype="multipart/form-data">
   <h3>You Can Also Include A File</h3>
        <input type="file" name="file">  
        <input type="submit" class="btn btn-success" name="submit" value="submit"><br>
<?php
if(isset($_POST['submit'])){
$name = $_FILES['file']['name'];
 $size = $_FILES['file']['size'];
$tmp_name = $_FILES['file']['tmp_name'];

if (isset($name)){
if(!empty($name)){

    $location = 'upload/';

    if(move_uploaded_file($tmp_name,$name)&&file_exists("upload/".$name)){


echo '<script language="javascript">alert(" Sorry!! Filename Already Exists...")</script>';

    }else{
?>
<script>alert("Upload succesful")</script>';
<?
echo "Uploaded".$name;
$upload = $user->Upload($Blog_ID,$location.$name);

}



}
}
}
 ?>     

</form>   


  
    <form method="post" action="PostReply2.php?Blog_ID=<?echo $Blog_ID?>">


    <table width="100%">
      <?php
//getting id from url
$Blog_ID = $_GET['Blog_ID'];

//selecting data associated with this particular id
  


       $Forumn = $user->getSelectedForum($Blog_ID);

       
        

// echo "<table><tr><th>ID</th><th>Name</th><th>E-mail</th><th>Gender</th><th>Birth Date</th><th>Website</th><th>Address</th><th>Province</th><th>Zip Code</th><th>City</th><th>Join Date</th><th>Annual Basic Pay</th></tr>";

while($row = mysqli_fetch_array($Forumn))
{
    $Blog_ID = $row['Blog_ID'];
    $Content = $row["Blog_Content"];
    $Title = $row["Blog_Title"];
     $date = $row["Date_Posted"];
     $time = $row['Time_Posted'];
  
}
?>

<div class="panel panel-default" style="width: 50%; ">
<div class="panel-heading">
<h3 class="panel-title text-center" >HEADING :<?echo $Title;?></h3>
<h5 class ="panel-title text-center">Date : <?echo $date?></h5>
<h5 class ="panel-title text-center">Time : <?echo $time?></h5>
</div>

<div class="panel-body text-center">
 <h2><? echo $Content;   ?></h2>

</div>


</div>


    
  <td colspan='2'>
    <p>Comments(<?$user->countComments($Blog_ID);?>) || <a href="viewFiles.php?Blog_ID=<?echo $_GET['Blog_ID'];?> ">Uploaded files(<?  $user->countFiles($Blog_ID)?> )</a> </p>
    <p> </p>
<tr><td colspan='2'><button class="btn btn-lg btn-primary" type="submit" data-toggle="modal" data-target="#myModal">Add A Comment</button>
  <hr/>
  <div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Modal Header</h4>
      </div>
      <div class="modal-body">
        <p>Some text in the modal.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
      

<h1 class="bottom_f w3-text-blue w3-card-2 w3-padding">Recent Comments..</h1>


</table>
</form>

  </div>

  <form method="post" action="">
    <table width="100%">
<?
$Blog_ID = $_GET['Blog_ID'];

//selecting data associated with this particular id
  


       $Forumn = $user->DisPCom($Blog_ID);
       while ($row = mysqli_fetch_array($Forumn)) {
        ?>
          <div id="wrapper">
        <tr><h6 style=""><?echo $row['Comment_Detail'];?></h6></tr>
        <?
        $User_ID = $row['User_ID'];
        
        
        
        
        ?>
        <p  class="3-bold w3-animate-zoom" style="text-transform:none; float: ;">by:<?php $user->get_Username($User_ID); ?></p></tr>
         <tr></tr>
       </div>

       <?  # code...
       }



?>





    </table>
    </form>
  </div>
  <div id="footer">
   
  <!-- end #footer -->
  </div>
<!-- end #container -->
</div>
</div>
</body>
</html>