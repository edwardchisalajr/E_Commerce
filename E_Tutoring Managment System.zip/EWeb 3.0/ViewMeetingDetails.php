<?
session_start();
include 'include/class.meeting.php';
include 'include/class.tutor.php';

$Meeting = new Meeting();
$tutor = new Tutor();
$MeetingDetails = $Meeting->getMeetingDetailsDetails($_GET['eventID']);
$row=mysqli_fetch_array($MeetingDetails);
$meeting_id= $row['Meeting_ID'];
$MeetingTitle = $row['Meeting_Subject'];
$MeetingStart = $row['start_time'];
$MeetingEnd = $row['end_time'];
$MeetingContent = $row['Meeting_Content'];


if (isset($_POST['submit'])){
        extract($_POST);

        $MeetingDescription = $Meeting->AddDescription($_GET['eventID'],$Description);
        if(isset($_POST['chosen_students'])){
    
       
        if ($MeetingDescription) {
             
            echo "<div style='text-align:center'>Description Added</div>"; 
        } else {
            // Registration Failed
            echo "<div style='text-align:center'>failed.</div>";
        }
    }
}
    if(isset($_POST['chosen_students'])&&isset($_POST['Assign'])){
    
    foreach($_POST['chosen_students'] as $selected){
    $Studentdetails = $tutor->getStudentDetails($selected);
    $studentRow=mysqli_fetch_array($Studentdetails);
    $Student_id = $studentRow['Student_ID'];
    
    $AssignMeeting = $tutor->AssignStudentsToMeetings($_GET['eventID'],$Student_id);    
    }
}
	
?>
<link href="css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<link href="css/displaycss.css" rel="stylesheet" id="bootstrap-css">
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link href="css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN"
        crossorigin="anonymous">
        
<script src="js/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
 <script src="js/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
        crossorigin="anonymous"></script>
<script src="js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy"
        crossorigin="anonymous"></script>
        
<nav class="navbar navbar-light bg-white">
        <a href="#" class="navbar-brand"><?echo $MeetingTitle ?></a>
        <form class="form-inline">
            <div class="input-group">
               </div>
        </form>
    </nav>


    <div class="container-fluid gedf-wrapper">
        <div class="row">
 
            <div class="col-md-6 gedf-main">

                <!--- \\\\\\\Post-->
                <div class="card gedf-card">
                    <div class="card-header">
                        <ul class="nav nav-tabs card-header-tabs" id="myTab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="posts-tab" data-toggle="tab" href="#posts" role="tab" aria-controls="posts" aria-selected="true">Meeting Details</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="images-tab" data-toggle="tab" role="tab" aria-controls="images" aria-selected="false" href="#images">Add Description</a>
                            </li>
                        </ul>
                    </div>
                    <div class="card-body">
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="posts" role="tabpanel" aria-labelledby="posts-tab">
							
							
							
                                <div class="form-group">
								 Start Date and Time: <?echo   $MeetingStart;?>
									  
                                </div>
								<div class="form-group">
								 End Date and Time: <?echo $MeetingEnd;?> 
									  
                                </div>
								<div class="form-group">
								 Meeting Description: <?if($MeetingContent==null){
									 echo ": Undefined";
								 }
								 else{
									 echo $MeetingContent;
								 }?> 
									  
                                </div>

                            </div>
                            <div class="tab-pane fade" id="images" role="tabpanel" aria-labelledby="images-tab">
                                <div class="form-group">
                                    <div class="custom-file">
                                    <form class="form-horizontal custom-form" method="post"name ="reg">
                                    <textarea class="form-control" name="Description" id="message" rows="3" placeholder="Meeting Description"></textarea>
									</br>
										<input type="submit" name="submit" class="btn btn-default btn-primary" value="Save" onclick="return(submitreg());"> 
										</form>
                                    </div>
                                </div>
                                <div class="py-4"></div>
                            </div>
                        </div>
 
                    </div>
                </div> 



        
			 

                <!--- \\\\\\\Post-->
                <div class="card gedf-card">
                    <div class="card-header">
                        <ul class="nav nav-tabs card-header-tabs" id="myTab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="posts-tab" data-toggle="tab" href="#Attending" role="tab" aria-controls="posts" aria-selected="true">Assign Students</a>
                            </li>
                             
                        </ul>
                    </div>
                    <div class="card-body">
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="Attending" role="tabpanel" aria-labelledby="posts-tab">
							
							
							
                                <div class="form-group">
								                            <table class="table">
					<form action="#" method="post">
					<table class="table table-striped table-bordered">
						<thead>
							<tr>
								<th>First Name</th>
								<th>Last Name</th> 
								<th>Assign</th> 
							</tr>
						</thead>
						<tbody >
							<tr>
							<?
							$Students = $Meeting->getStudents($_SESSION['Tutor_ID'],$_GET['eventID']);
							while( $row=mysqli_fetch_array($Students)){
				
							?>
								<td><?php echo $row['fname']; ?></td>
								<td><?php echo $row['lname']; ?></td> 

								<td class="td-actions">
									<a href="javascript:;" class="btn btn-small btn-primary">
										<i class="btn-icon-only icon-ok"><input type="checkbox" name="chosen_students[]" value="<?php echo $row['User_ID'];?>"></i>										
									</a>
								</td>
							</tr>
							<?
							}
							?>
							
							
							</tbody>
						</table>
						<tr>
          
          
						<input type="submit" name="Assign" class="btn  btn-primary" value="Submit" />
						</form>
					
                                
                                </table>
                                </div>

                            </div>
                           
                        </div>
 
                    </div>
                </div> 



            </div>
            <div class="col-md-6">
                <div class="card gedf-card">
                    <div class="card-header">
                        <ul class="nav nav-tabs card-header-tabs" id="myTab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="posts-tab" data-toggle="tab" href="#AttendingStudents" role="tab" aria-controls="posts" aria-selected="true">Attending List</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="images-tab" data-toggle="tab" role="tab" aria-controls="images" aria-selected="false" href="#PendingStudents">Pending List</a>
                            </li>
							 <li class="nav-item">
                                <a class="nav-link" id="images-tab" data-toggle="tab" role="tab" aria-controls="images" aria-selected="false" href="#DeclinedStudents">Declined</a>
                            </li> 
                        </ul>
                    </div>
                    <div class="card-body">
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="AttendingStudents" role="tabpanel" aria-labelledby="posts-tab">
							
							
							
                                <div class="form-group">
								 
								 Attending
                                </div>

                            </div>
                            <div class="tab-pane fade" id="PendingStudents" role="tabpanel" aria-labelledby="images-tab">
                                <div class="form-group">
                                   <table class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>First Name</th>
                                <th>Last Name</th> 
                                <th>Email Address</th> 
                            </tr>
                        </thead>
                        <tbody >
                            <tr>
                            <?
                            $Students = $Meeting->DisplayPendingStudents($_GET['eventID']);
                            while($row=mysqli_fetch_array($Students)){
                
                            ?>
                                <td><?php echo $row['fname']; ?></td>
                                <td><?php echo $row['lname']; ?></td> 
                                <td><?php echo $row['email']; ?></td> 
                                
                                   
                                       
                                    </a>
                                </td>
                            </tr>
                            <?
                            }
                            ?>
                            
                            
                            </tbody>
                        </table>
                                </div>
                                <div class="py-4"></div>
                            </div>
							 <div class="tab-pane fade" id="DeclinedStudents" role="tabpanel" aria-labelledby="images-tab">
                                <div class="form-group">
                                    Declined
                                </div>
                                <div class="py-4"></div>
                            </div>
                        </div>
                </div>
 
            </div>
        </div>
    </div>
	
	<script>
      function submitreg() {
        var form = document.reg;
        if (form.Description.value == "") {
          alert("Enter Username.");
          return false;
        }
      }
    </script>