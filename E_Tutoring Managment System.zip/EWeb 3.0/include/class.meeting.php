<?php

include_once 'db_config.php';


class meeting {
		protected $db;
			public function __construct(){
					$this->db = new DB_con();
					$this->db = $this->db->ret_obj();
			}
			 
			public function getMeetingDetailsDetails($EventID){
					$query = "SELECT * FROM meeting_tbl WHERE Meeting_ID = $EventID";
					$result = $this->db->query($query) or die($this->db->error);
					return $result;
			}
			public function AddDescription($Meeting_ID,$Description){
					$query = "Update meeting_tbl set Meeting_Content = '$Description' where Meeting_ID = '$Meeting_ID'";
					$result = $this->db->query($query) or die($this->db->error);
					if($result){
						echo "Description Added";
						return true;
					}
					echo "An Error Occured";
					return false;
			}
			public function getStudents($Tutor_ID,$Meeting_ID){
					$query = "select user_tbl.User_ID,user_tbl.fname,user_tbl.lname,user_tbl.email from student_tbl
								  JOIN user_tbl on user_tbl.User_ID = student_tbl.User_ID
								  join tutor_student_tbl on tutor_student_tbl.Student_id = student_tbl.Student_ID
								  join tutor_tbl on tutor_tbl.Tutor_id = tutor_student_tbl.Tutor_ID 
								  where tutor_tbl.Tutor_id = $Tutor_ID AND student_tbl.Student_ID NOT IN (
select student_tbl.Student_ID from student_tbl 
								  JOIN meeting_students_tbl on student_tbl.Student_ID = meeting_students_tbl.student_id where meeting_students_tbl.meeting_id = $Meeting_ID);";
					$result = $this->db->query($query) or die($this->db->error);
					return $result;
			}
			
public function DisplayPendingStudents($meeting_id){
					$query = "select student_tbl.Student_ID,user_tbl.fname,user_tbl.lname,user_tbl.email from student_tbl 
					JOIN user_tbl on user_tbl.User_ID = student_tbl.User_ID
								  JOIN meeting_students_tbl on student_tbl.Student_ID = meeting_students_tbl.student_id where meeting_students_tbl.meeting_id = $meeting_id
								  AND Status = 'pending'";
					$result = $this->db->query($query) or die($this->db->error);

					return $result;
			
}
public function DisplayAttendingStudents($meeting_id){
					$query = "select student_tbl.Student_ID,user_tbl.fname,user_tbl.lname,user_tbl.email from student_tbl 
					JOIN user_tbl on user_tbl.User_ID = student_tbl.User_ID
								  JOIN meeting_students_tbl on student_tbl.Student_ID = meeting_students_tbl.student_id where meeting_students_tbl.meeting_id = $meeting_id
								  AND Status = 'Accepted'";
					$result = $this->db->query($query) or die($this->db->error);

					return $result;
			
}public function DisplayDeclinedStudents($meeting_id){
					$query = "select student_tbl.Student_ID,user_tbl.fname,user_tbl.lname,user_tbl.email from student_tbl 
					JOIN user_tbl on user_tbl.User_ID = student_tbl.User_ID
								  JOIN meeting_students_tbl on student_tbl.Student_ID = meeting_students_tbl.student_id where meeting_students_tbl.meeting_id = $meeting_id
								  AND Status = 'declined'";
					$result = $this->db->query($query) or die($this->db->error);

					return $result;
			
} 
}
?>