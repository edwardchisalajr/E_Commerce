<?php
include("config.php");
session_start();
$Student_id = $_SESSION['Student_ID'];

if(isset($_POST['action']) or isset($_GET['view']))  
{
	
    if(isset($_GET['view']))
    {
        header('Content-Type: application/json');
        $start = mysqli_real_escape_string($dbcon,$_GET["start"]);
        $end = mysqli_real_escape_string($dbcon,$_GET["end"]);
    
        $result = mysqli_query($dbcon,"SELECT meeting_tbl.Meeting_ID as id, start_time as start,end_time as end,Meeting_Subject as title FROM  meeting_students_tbl
			JOIN meeting_tbl on meeting_students_tbl.meeting_id = meeting_tbl.Meeting_ID
            JOIN tutor_student_tbl on tutor_student_tbl.Tutor_ID = meeting_tbl.Tutor_ID where tutor_student_tbl.Student_id = '$Student_id'
                                        ");
        while($row = mysqli_fetch_assoc($result))
        {
            $events[] = $row; 
        }
        echo json_encode($events); 
        exit;
    }
    elseif($_POST['action'] == "accept") 
    {
 $id = $_POST['id'];
        mysqli_query($dbcon,"UPDATE meeting_students_tbl set 
            Status = 'Accepted'
            where student_id = '$Student_id' AND meeting_id = '$id'");
        if (mysqli_affected_rows($dbcon) > 0) {
            echo "1";
        }
        exit;
    }
    elseif($_POST['action'] == "decline")  
    {
	 $id = $_POST['id'];
        mysqli_query($dbcon,"UPDATE meeting_students_tbl set 
            Status = 'declined'
            where student_id = '$Student_id' AND meeting_id = '$id'");
        if (mysqli_affected_rows($dbcon) > 0) {
            echo "1";
        }
        exit;
    }
}
?>