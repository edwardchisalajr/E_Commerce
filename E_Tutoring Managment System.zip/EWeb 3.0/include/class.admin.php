<?php

include_once 'db_config.php';


class admin {
		protected $db;
			public function __construct(){
					$this->db = new DB_con();
					$this->db = $this->db->ret_obj();
			}
			public function reg_user($uname, $Firstname, $Lastname, $uemail,$upass){
			$query = "SELECT * FROM user_tbl WHERE username='$uname' AND password='$upass'";
			
			$result = $this->db->query($query) or die($this->db->error);
			
			$count_row = $result->num_rows;
			
			
			if($count_row == 0){
				$query = "INSERT INTO user_tbl SET username='$uname', password='$upass', fname='$Firstname', email='$uemail', lname='$Lastname', user_type='Tutor',Visits = '0',Status = 'Accepted'";
				
				$result = $this->db->query($query) or die($this->db->error);
				
				return true;
			}
			else{return false;
				}
			}
			 public function reg_tutor($uname,$upass,$qualification){
			$query = "SELECT * FROM user_tbl WHERE username='$uname' AND password = '$upass'";
			
			$result = $this->db->query($query) or die($this->db->error);
			
			$count_row = $result->num_rows;
			$user_data = $result->fetch_array(MYSQLI_ASSOC);
			$userid = $user_data['User_ID']+1-1;
			
			if($count_row == 1){
				$query = "INSERT INTO tutor_tbl SET User_ID = '$userid',Qualification='$qualification'";
				
				$result = $this->db->query($query) or die($this->db->error);
				
				return true;
			}
			else{return false;}
			
			
			
			}
			

			public function getStudentDetails($User_ID){
					$query = "SELECT * FROM student_tbl WHERE User_ID = $User_ID";
					$result = $this->db->query($query) or die($this->db->error);
					return $result;
			}
			
			public function getTutorDetails($User_ID){
					$query = "SELECT * FROM tutor_tbl WHERE User_ID = $User_ID";
					$result = $this->db->query($query) or die($this->db->error);
					return $result;
			}

			public function getStudents(){
					$query = "select * from student_tbl
							  JOIN user_tbl on user_tbl.User_ID = student_tbl.User_ID
							  LEFT OUTER JOIN tutor_student_tbl on tutor_student_tbl.Student_id = student_tbl.Student_ID
							  where tutor_student_tbl.Student_ID is NULL";
					$result = $this->db->query($query) or die($this->db->error);
					return $result;
			}
			public function CountStudentsWithTutor(){
					$query = "select count(tutor_student_tbl.Student_id) as Students from student_tbl
							  JOIN user_tbl on user_tbl.User_ID = student_tbl.User_ID
							  JOIN tutor_student_tbl on tutor_student_tbl.Student_id = student_tbl.Student_ID";
					$result = $this->db->query($query) or die($this->db->error);
					return $result;
			}	
			
			public function CountStudentsWithoutTutor(){
					$query = "select count(student_tbl.Student_ID ) as Students from student_tbl
							  JOIN user_tbl on user_tbl.User_ID = student_tbl.User_ID
							  LEFT OUTER JOIN tutor_student_tbl on tutor_student_tbl.Student_id = student_tbl.Student_ID
							  where tutor_student_tbl.Student_ID is NULL";
					$result = $this->db->query($query) or die($this->db->error);
					return $result;
			}
			
			public function getStudentsWithTutors(){
					$query = "select count(tutor_student_tbl.Student_id) as Students from student_tbl
							  JOIN user_tbl on user_tbl.User_ID = student_tbl.User_ID
							  LEFT OUTER JOIN tutor_student_tbl on tutor_student_tbl.Student_id = student_tbl.Student_ID
							  where tutor_student_tbl.Student_ID is NULL";
					$result = $this->db->query($query) or die($this->db->error);
					return $result;
			}
			
			
			
			public function getAssignedStudents($Tutor_ID){
					$query = "select user_tbl.User_ID,user_tbl.fname,user_tbl.lname,user_tbl.email from student_tbl
								  JOIN user_tbl on user_tbl.User_ID = student_tbl.User_ID
								  join tutor_student_tbl on tutor_student_tbl.Student_id = student_tbl.Student_ID
								  join tutor_tbl on tutor_tbl.Tutor_id = tutor_student_tbl.Tutor_ID
								  where tutor_tbl.Tutor_id = $Tutor_ID;";
					$result = $this->db->query($query) or die($this->db->error);
					return $result;
			}

			public function getTutors(){
					$query = "SELECT * FROM user_tbl WHERE user_type = 'Tutor'";
					$result = $this->db->query($query) or die($this->db->error);
					return $result;
			}
			
			public function getAllStudents(){
					$query = "SELECT * FROM user_tbl WHERE user_type = 'Student'";
					$result = $this->db->query($query) or die($this->db->error);
					return $result;
			}
			public function getAllPendingStudents(){
					$query = "SELECT * FROM user_tbl WHERE user_type = 'Student' AND Status = 'Pending'";
					$result = $this->db->query($query) or die($this->db->error);
					return $result;
			}
			

			
			public function countTutors(){
					$query = "SELECT count(user_type) as TotalTutors FROM user_tbl WHERE user_type = 'Tutor'";
					$result = $this->db->query($query) or die($this->db->error);
					return $result;
			}
			public function countStudents(){
					$query = "SELECT count(user_type) as TotalStudents FROM user_tbl WHERE user_type = 'Student'";
					$result = $this->db->query($query) or die($this->db->error);
					return $result;
			}

			public function countUsers(){
					$query = "SELECT count(user_type) as TotalUsers FROM user_tbl";
					$result = $this->db->query($query) or die($this->db->error);
					return $result;
			}
			public function countAdmins(){
					$query = "SELECT count(user_type) as TotalAdmins FROM user_tbl WHERE user_type = 'Admin'";
					$result = $this->db->query($query) or die($this->db->error);
					return $result;
			}

			
			public function AssignStudents($tutor_id,$Student_id){
					$query = "INSERT INTO tutor_student_tbl (Tutor_ID,Student_id) VALUES ($tutor_id,$Student_id)";
					$result = $this->db->query($query) or die($this->db->error);
					if($result){
						echo "<center><h5>Students Assigned Successfuly!!!!</h5></center>";
						
						return true;
					}
					echo "An Error Occured";
					return false;
			}
			
			public function ReAssignStudents($tutor_id,$Student_id){
					$query = "Update tutor_student_tbl SET Tutor_ID = '$tutor_id' WHERE Student_id = $Student_id";
					$result = $this->db->query($query) or die($this->db->error);
					if($result){
						echo "<center>Students Successfuly Ressigned</center>";
						return true;
					}
					echo "An Error Occured";
					return false;
			}
			
				
			public function AcceptStudent($User_ID){
					$query = "Update user_tbl SET Status = 'Accepted' WHERE User_ID = $User_ID";
					$result = $this->db->query($query) or die($this->db->error);
					if($result){
						echo "<center>Student Successfuly Accepted</center>";
						return true;
					}
					echo "An Error Occured";
					return false;
			}
			public function DeclineStudent($User_ID){
					$query = "Update user_tbl SET Status = 'Declined' WHERE User_ID = '$User_ID'";
					$result = $this->db->query($query) or die($this->db->error);
					if($result){
						echo "<center>Student Application Declined</center>";
						return true;
					}
					echo "An Error Occured";
					return false;
			}
			
			
			
			
			public function CountAllTutorStudents(){
					$query = "Select fname,lname, count(Student_id) as AssignedStudents
								from tutor_tbl
								  LEFT OUTER JOIN user_tbl on tutor_tbl.User_ID = user_tbl.User_ID
								  LEFT OUTER JOIN tutor_student_tbl on tutor_tbl.Tutor_id = tutor_student_tbl.Tutor_ID
								GROUP BY fname";
					$result = $this->db->query($query) or die($this->db->error);
 
					return $result;
			 
				 
			}
			
						
			public function CountTutorWithoutStudents(){
					$query = "select count(lname) as Tutors from tutor_tbl
							  JOIN user_tbl on user_tbl.User_ID = tutor_tbl.User_ID
							  LEFT OUTER JOIN tutor_student_tbl on tutor_student_tbl.Tutor_id = tutor_tbl.Tutor_id
							  where tutor_student_tbl.Tutor_id is NULL
							   ";
					$result = $this->db->query($query) or die($this->db->error);
					return $result;
			}
			
			public function CountTutorWithStudents(){
					$query = "Select count(DISTINCT Tutor_ID) as Tutors from  
							  tutor_student_tbl  
							  ";
					$result = $this->db->query($query) or die($this->db->error);
					return $result;
			}
		
			public function CountTutorsStudents($User_ID){
					$query = "select  lname, count(Student_id) AS StudentsNum from tutor_tbl
								join user_tbl on user_tbl.User_ID = tutor_tbl.User_ID
								join tutor_student_tbl on tutor_student_tbl.Tutor_ID = tutor_tbl.Tutor_id
								where user_tbl.User_ID = $User_ID
								group by lname 
							  ";
					$result = $this->db->query($query) or die($this->db->error);
					$user_data = mysqli_fetch_array($result);
					if($user_data['StudentsNum']==0){
						echo 0;
					}
						echo $user_data['StudentsNum'];;			
			}
			
			public function countSentMessages($User_ID,$Date){
					$query = "select *,count(Messege_ID) as sent from message_tbl where SentFrom = '$User_ID' AND DateSent = '$Date'";
					$result = $this->db->query($query) or die($this->db->error);
					return $result;
			}	
			
			public function countRecievedMessages($Tutor_ID,$User_ID,$Date){
					$query = "select *,count(Messege_ID) as Recieved from message_tbl where Tutor_ID = '$Tutor_ID' AND DateSent = '$Date' AND SentFrom != '$User_ID'";
					$result = $this->db->query($query) or die($this->db->error);
					return $result;
			}
			
			public function countStudentRecievedMessages($Student_id,$User_ID,$Date){
					$query = "select *,count(Messege_ID) as Recieved from message_tbl where Student_ID = '$Student_id' AND DateSent = '$Date' AND SentFrom != '$User_ID'";
					$result = $this->db->query($query) or die($this->db->error);
					return $result;
			}
			
			public function countAcceptedMeetings($Student_id){
					$query = "select *,count(meeting_id) as Accepted from meeting_students_tbl where student_id = '$Student_id' AND Status = 'Accepted'";
					$result = $this->db->query($query) or die($this->db->error);
					return $result;
			}
			public function countPendingMeetings($Student_id){
					$query = "select *,count(meeting_id) as Pending from meeting_students_tbl where student_id = '$Student_id' AND Status = 'pending'";
					$result = $this->db->query($query) or die($this->db->error);
					return $result;
			}
			public function countDeniedMeetings($Student_id){
					$query = "select *,count(meeting_id) as Declined from meeting_students_tbl where student_id = '$Student_id' AND Status = 'declined'";
					$result = $this->db->query($query) or die($this->db->error);
					return $result;
			}
			
			
			
 			public function getTutorID($User_ID){
					$query = "SELECT * FROM tutor_tbl join user_tbl on user_tbl.User_ID = tutor_tbl.User_ID WHERE user_tbl.User_ID = '$User_ID'";
					$result = $this->db->query($query) or die($this->db->error);
					return $result;
			}
			
			public function getStudentID($User_ID){
					$query = "SELECT * FROM student_tbl join user_tbl on user_tbl.User_ID = student_tbl.User_ID WHERE user_tbl.User_ID = '$User_ID'";
					$result = $this->db->query($query) or die($this->db->error);
					return $result;
			}
			
			
			
			public function getMessageActivity($Date){
					$query = "			select DISTINCT * from user_tbl
										JOIN student_tbl on user_tbl.User_ID = student_tbl.User_ID
										LEFT OUTER JOIN message_tbl on message_tbl.SentFrom = student_tbl.User_ID
										WHERE DateSent < '2018-11-02' OR DateSent is NULL;";
					$result = $this->db->query($query) or die($this->db->error);
					return $result;
			}
			
		
			
			

			
			
			
		
}
?>