<?
include 'include/class.admin.php';
$admin = new Admin();
$CountStudentsWithTutors = $admin->CountStudentsWithTutor();
$CountStudentsWithTutorsRows = mysqli_fetch_array($CountStudentsWithTutors);
$CountStudentsWithTutors = $CountStudentsWithTutorsRows['Students'];

$CountStudentsWithoutTutors = $admin->CountStudentsWithoutTutor();
$CountStudentsWithoutTutorsRows = mysqli_fetch_array($CountStudentsWithoutTutors);
$CountStudentsWithoutTutors = $CountStudentsWithoutTutorsRows['Students'];

$TotalStudents = $CountStudentsWithoutTutors+$CountStudentsWithTutors;

$WithTutors = $CountStudentsWithTutors/$TotalStudents*100;

$WithoutTutors = $CountStudentsWithoutTutors/$TotalStudents*100;
?>
<head>

   <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Homepage</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ETUTORING</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/user.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="css/dashstyle.css">

    <!--  -->
<link href="css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN"
        crossorigin="anonymous">
        <link rel="stylesheet" href="styl.css">

<link href="css/displaycss.css" rel="stylesheet" id="bootstrap-css">
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.min.js"></script>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
<script>
window.onload = function () {
 
var chart = new CanvasJS.Chart("piechartContainer", {
	exportEnabled: true,
	animationEnabled: true,
	title:{
		text: "Tutor Assigning Graph"
	},
	legend:{
		cursor: "pointer",
		itemclick: explodePie
	},
	data: [{
		type: "pie",

		showInLegend: true,
		toolTipContent: "{name}: <strong>{y}%</strong>",
		indexLabel: "{name} - {y}%",
		dataPoints: [
			{ y: <?echo $WithTutors?>, name: " Students With Tutors ", exploded: true },
			{ y: <?echo $WithoutTutors?>, name: "Students Without Tutors  ", exploded: true  }

		]
	}]
});
chart.render();
}

function explodePie (e) {
	if(typeof (e.dataSeries.dataPoints[e.dataPointIndex].exploded) === "undefined" || !e.dataSeries.dataPoints[e.dataPointIndex].exploded) {
		e.dataSeries.dataPoints[e.dataPointIndex].exploded = true;
	} else {
		e.dataSeries.dataPoints[e.dataPointIndex].exploded = false;
	}
	e.chart.render();
}
</script>
</head>

<body>
<nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container">
            <div class="navbar-header"><a class="navbar-brand navbar-link" href="AdminDash.php"><i class="fa fa-fw fa-user "></i> Admin Account</a>
                
                
            
                <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            </div>



            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="nav navbar-nav navbar-right">
                   <li class="">
                        <a href="AdminDash.php"><i class="fa fa-fw fa-home fa-2x"></i> Dashboard</a>
                    </li>
                    <li>
                        <a href="AssignStudents.php"><i class="fa fa-users fa-fw fa-2x"></i> Assing student</a>
                    </li>
                    

                

                    <li>
                        <a href="bootstrap-grid.html"><i class="fa fa-fw fa-twitter fa-2x"></i> Blog</a>
                    </li>

                    
                    
                </ul>
            </div>
        </div>
    </nav>
    <br><br><br><br>






 
<div class="container bootstrap snippet">

<div id="piechartContainer" style="height: 370px; max-width: 920px; margin: 0px auto;"></div>
		<script src="js/canvasjs.min.js"></script>
</div> 
<br>
<div class="container bootstrap snippet">
 <table class="table">
					<form action="#" method="post">
					<table class="table table-striped table-bordered"><i class="fa fa-users fa-2x"></i>
					Inactive Students this Week
						<thead>
						
							<tr>
								<th>First Name</th>
								<th>Last Name</th>
								<th>Email</th>
								 
							 
							</tr>
						</thead>
						<tbody >
							<tr>
							<?
							
							$today = date("Y-m-d");
							$tempdate =  strtotime('-6 day',strtotime($today));
							$Week = date("Y-m-d",$tempdate);
							$Students = $admin->getMessageActivity($Week);
							while( $row=mysqli_fetch_array($Students)){
				
							?>
								<td><?php echo $row['fname']; ?></td>
								<td><?php echo $row['lname']; ?></td>
								<td><?php echo $row['email']; ?></td>
				 
							</tr>
							<?
							}
							?>
							
							
							</tbody>
						</table>

						<br>
						
						
						 <table class="table">
					<form action="#" method="post">
					<table class="table table-bordered"><i class="fa fa-users fa-2x"></i>
					Inactive Students this Month
						<thead>
						
							<tr>
								<th>First Name</th>
								<th>Last Name</th>
								<th>Email</th>
								 
							 
							</tr>
						</thead>
						<tbody >
							<tr>
							<?
							
							$today = date("Y-m-d");
							$tempdate =  strtotime('-30 day',strtotime($today));
							$Week = date("Y-m-d",$tempdate);
							$Students = $admin->getMessageActivity($Week);
							while( $row=mysqli_fetch_array($Students)){
				
							?>
								<td><?php echo $row['fname']; ?></td>
								<td><?php echo $row['lname']; ?></td>
								<td><?php echo $row['email']; ?></td>
				 
							</tr>
							<?
							}
							?>
							
							
							</tbody>
						</table>
						
						
 </div>
  
</div>
<br>
<div class="container bootstrap snippet"><i class="fa fa-users fa-2x"></i>
All Students
 					<table class="table table-striped table-bordered">
						<thead>
							<tr>
								<th>First Name</th>
								<th>Last Name</th> 
								<th>Email</th>  
								
							</tr>
						</thead>
						<tbody >
							<tr>
							<?
							$Students = $admin->getAllStudents();
							while( $row=mysqli_fetch_array($Students)){
							$UserID = $row['User_ID'];
							?>
								<td><?php echo $row['fname']; ?></td>
								<td><?php echo $row['lname']; ?></td> 
								<td><?php echo $row['email']; ?></td>
								<td><a button class="btn btn-danger" title="Click here to View." href = "StudentStats.php?UserID=<?echo $UserID?>">StudentsStats</a></td>
								
							</tr>
							<?
							}
							?>
							
							
							</tbody>
						</table>
</div> 


</div>
 