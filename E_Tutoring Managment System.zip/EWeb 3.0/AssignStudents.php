<?
include 'include/class.admin.php';
$Admin = new Admin();

		
?>

<!DOCTYPE html>
<html lang="en">

<head>

   <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Homepage</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ETUTORING</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/user.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="css/dashstyle.css">

    <!--  -->
<link href="css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN"
        crossorigin="anonymous">
        <link rel="stylesheet" href="styl.css">

<link href="css/displaycss.css" rel="stylesheet" id="bootstrap-css">
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link href="css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN"
        crossorigin="anonymous">
        
<script src="js/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
 <script src="js/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
        crossorigin="anonymous"></script>
<script src="js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy"
        crossorigin="anonymous"></script>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</head>
<nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container">
            <div class="navbar-header"><a class="navbar-brand navbar-link" href="AdminDash.php"><i class="fa fa-fw fa-user"></i> Admin Account</a>
                
                
            
                <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            </div>



            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="nav navbar-nav navbar-right">
                   <li class="">
                        <a href="AdminDash.php"><i class="fa fa-fw fa-home fa-2x"></i> Dashboard</a>
                    </li>
                    <li>
                        <a href="AssignStudents.php"><i class="fa fa-users fa-fw fa-2x"></i> Assign student</a>
                    </li>
                    

                    

                    <li>
                        <a href="bootstrap-grid.html"><i class="fa fa-fw fa-twitter fa-2x"></i> Blog</a>
                    </li>


                    
                    
                </ul>
            </div>
        </div>
    </nav>
    <br><br><br><br>
<div class="span7">   
    

    
    
    
<div class="widget stacked widget-table action-table">
    				    <div class="container"> 
                            <div class="table-responsive">      
                            <table class="table">
				<div class="widget-header">
					<i class="icon-th-list"></i>
					<h3>Students without tutors</h3>
					<?php 


if(isset($_POST['chosen_students'])){
	
	foreach($_POST['chosen_students'] as $selected){
	$Studentdetails = $Admin->getStudentDetails($selected);
	$studentRow=mysqli_fetch_array($Studentdetails);
	$Student_id = $studentRow['Student_ID'];
	$temptutorid = $_POST['Tutor'];
	$TutorDetails = $Admin->getTutorDetails($temptutorid);
	$tutorRow=mysqli_fetch_array($TutorDetails);
	$tutor_id = $tutorRow['Tutor_id'];
	$Assign = $Admin->AssignStudents($tutor_id,$Student_id);

	}
}
	
					?>
				</div> 
				
				<div class="widget-content">
                    <div class="container"> 
                            <div class="table-responsive">      
                            <table class="table">
					<form action="#" method="post">
					<table class="table table-striped table-bordered">
						<thead>
							<tr>
								<th>First Name</th>
								<th>Last Name</th>
								<th>Email</th>
								<th>Assign</th>
								<th class="td-actions"></th>
							</tr>
						</thead>
						<tbody >
							<tr>
							<?
							$Students = $Admin->getStudents();
							while( $row=mysqli_fetch_array($Students)){
				
							?>
								<td><?php echo $row['fname']; ?></td>
								<td><?php echo $row['lname']; ?></td>
								<td><?php echo $row['email']; ?></td>
								<td class="td-actions">
									<a href="javascript:;" class="btn btn-small btn-danger">
										<i class="btn-icon-only icon-ok"><input type="checkbox" name="chosen_students[]" value="<?php echo $row['User_ID'];?>"></i>										
									</a>
								</td>
							</tr>
							<?
							}
							?>
							
							
							</tbody>
						</table>
						<tr>
              <h4>Select  Tutor</h4>
			  <select name = "Tutor">
			<?
							$Tutors = $Admin->getTutors();
							while( $row=mysqli_fetch_array($Tutors)){
				
			?>
              
			  <option value ="<?php echo $row['User_ID']; ?>"><?php echo $row['fname']; ?></option>
		
			<?
							}
			?>
				  </select>
            
          
						

						<button type='submit' class="btn btn-danger" name="submit"><i class="fa fa-fw fa-hand-pointer-o"></i></button>

						</form>
					
                                
                                </table>
				</div>
			
			</div>
            </div>
