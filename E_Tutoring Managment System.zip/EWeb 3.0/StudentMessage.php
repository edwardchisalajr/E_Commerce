<?
session_start();
include 'include/class.Student.php';
$Student = new Student();

if(isset($_POST['Message'])){
	$SendMessage = $Student->sendMessage($_GET['TutorID'],$_SESSION['Student_ID'],$_POST['Message']);
	if ($SendMessage) {
	      echo '';
	        
	    }
		else {
	       
	        echo 'Wrong username or password';
	    }
	}
?>



<link href="css/style.css" rel="stylesheet" id="bootstrap-css">

<html>
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Messaging</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/user.css">
</head>

<body>
<?
include 'header.php';
?>
<br><br><br><br>
<section class="message">
<h3 class=" text-center"><i class="fa fa-twitter"></i>Messaging</h3>

<div class="messaging">
<div class="container">
      <div class="inbox_msg">
        <div class="inbox_people">
          <div class="headind_srch">
            <div class="recent_heading">
              <h4>Your Tutor</h4>
            </div>
			
            <div class="srch_bar">
              <div class="stylish-input-group">
                 
                <span class="input-group-addon">
                <button type="button"> <i class="fa fa-search" aria-hidden="true"></i> </button>
                </span> </div>
            </div>
          </div>
          <div class="inbox_chat">
		  <?
							$Tutor = $Student->getTutor($_SESSION['Student_ID']);
							while( $row=mysqli_fetch_array($Tutor)){
							$Tutordetails = $Student->getTutorDetails($row['User_ID']);
							$TutorRow=mysqli_fetch_array($Tutordetails);
							$Tutor_ID = $TutorRow['Tutor_id'];
							
							
							?>
								<div class="chat_list active_chat">
								  <div class="chat_people">
									<div class="chat_img"> <img src="assets/img/user-profile.png" alt="sunil"> </div>
									<div class="chat_ib">
									  <h5><a href="StudentMessage.php?TutorID=<?php echo $Tutor_ID;?> "><?php echo $row['fname']; ?> <?php echo $row['lname']; ?> <?php echo $row['email']; ?></a>
									  
									</div>
								  </div>
								</div>
								 
							<?
							}
		?>
          </div>
        </div>
		<?
		if(isset($_GET['TutorID'])){
			?>
        <div class="mesgs">
          <div class="msg_history">
			   <?
			  $Message = $Student->getMessages($_GET['TutorID'],$_SESSION['Student_ID']);
			  $TutorUserID = $Student->getTutorUserID($_GET['TutorID']);
			  $TutorUserIDrow=mysqli_fetch_array($TutorUserID);
			  $TutorUserID = $TutorUserIDrow["User_ID"];
			  while( $row=mysqli_fetch_array($Message)){
				  if($row['SentFrom']==$TutorUserID){
					  ?>
						<div class="incoming_msg">
						 <div class="incoming_msg_img"> <img src="assets/img/user-profile.png" alt="sunil"> </div>
						  <div class="received_msg">
							<div class="received_withd_msg">
							  <p><? echo $row['MesseageText']?></p> 
							  </div>
						  </div>
						</div>
					  <?
				  }
				  else{
					  ?>
					    <div class="outgoing_msg">
						<div class="sent_msg">
							<p><? echo $row['MesseageText']?></p> 
							</div>
						</div>
					  <?
					  
				  }
			  }
              ?>
          </div>
          <div class="type_msg">
            <div class="input_msg_write">
			<form action="#" method="post">

              
              

<div class="col-xs-11">
      
      <input class="form-control input-lg" id="inputlg" name  = "Message" class="write_msg" placeholder="Type a message"/>
   

      <button type='submit' class="btn btn-success btn-lg" name="submit"><i class="fa fa-fw fa-whatsapp"></i></button>


			  </form>
			  <br>
            </div>
			
          </div>
        </div>
      </div>
			</section>
		<?}
      ?>
      <p class="text-center top_spac"><a target="_blank" href="#"><? echo $_SESSION['Student_ID'];?></a></p>
      
    </div></div>
    </body>
    </html>