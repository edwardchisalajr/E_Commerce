<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link href="bxslider/jquery.bxslider.css" rel="stylesheet" />
<script src="bxslider/jquery.min.js"></script>
<script src="bxslider/jquery.bxslider.min.js"></script>
<script type="text/javascript">

</script>
</head>
<body>
	<link href="style.css" rel="stylesheet">

	<div id="container">
	<header>   
	 <div id="brand">Logged in </div>
	  <nav>
	  	<ul>
	     <li><a href="#">Home</a></li>
	     <li><a href="#">My Profile</a></li>
	     <li><a href="#">DM</a></li>
	     <li><a href="#">My Students</a></li>
	     <li><a href="forumn.php">Forum</a></li>
	     <li><a href="home.php?q=logout">LOGOUT</a></li>

	  	</ul>

	  </nav>

    </header>
   
	
</p>
</section>
	    <footer id="foot">
	    	
	    	</section>
    </footer>
	</div>


 
</body>
</html>