<?php
session_start();
?>
<?php // require_once('connect.php'); ?>
<?

 include_once 'include/class.user.php';
   $user = new User();
   $Date_Commented = date('Y-m-d');
            $Time= date_create();
            $Time_Commented = date_format($Time,"h:m:s");


    $uid = $_SESSION['User_ID'];
    $Blog_ID =$_GET['Blog_ID'];

    if (!$user->get_session()){
       header("location:login.php");
    }

    if (isset($_GET['q'])){
        $user->user_logout();
        header("location:login.php");
        

    }


    if(isset($_POST['reply_submit'])){


      $Comment_Detail = $_POST["Comment_Detail"];
        $Comment = $user->Comment($Blog_ID,$Comment_Detail,$uid,$Time_Commented,$Date_Commented);
        
            echo "<div style='text-align:center'><script> alert('Comment successfuly sent');</script></div>";
    }
    else{

         echo "<div style='text-align:center'>Comment Failed</div>";
         
   
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Homepage</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ETUTORING</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/user.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="css/dashstyle.css">

    <!--  -->
<link href="css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN"
        crossorigin="anonymous">

<link href="css/displaycss.css" rel="stylesheet" id="bootstrap-css">
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link href="css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN"
        crossorigin="anonymous">
        
<script src="js/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
 <script src="js/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
        crossorigin="anonymous"></script>
<script src="js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy"
        crossorigin="anonymous"></script><nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container">
            <div class="navbar-header"><a class="navbar-brand navbar-link" href="StudentHome.php"><i class="fa fa-fw fa-user"></i> Student Account</a>
                
                
            
                <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            </div>



            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="nav navbar-nav navbar-right">
                   <li class="">
                        <a href="StudentHome.php"><i class="fa fa-fw fa-home fa-2x"></i> Dashboard</a>
                    </li>
                    <li>
                        <a href="StudentMessage.php"><i class="fa fa-fw fa-wechat fa-2x"></i> Messages</a>
                    </li>
                    

                    <li>
                        <a href="ViewMeetings.php"><i class="fa fa-fw fa-calendar fa-2x"></i> Meetings</a>
                    </li>

                    <li>
                        <a href="Forumn.php"><i class="fa fa-fw fa-twitter fa-2x"></i> Blog</a>
                    </li>

                     <li role="presentation"><a href="logout.php?q=logout"><i class="fa fa-fw fa-undo fa-2x"></i>Logout</a></li>

                    
                    
                </ul>
            </div>
        </div>
    </nav>
<br><br><br><br>

    </div>

<body>


<p><h3>Posting reply</h3></p>
<style type="text/css">


h3{
background-color:#CCCCCC;
text-align:center;

border:1px green solid;
}

</style>
</body>


<center><p><font color='brown'>You are logged in as(<?$user->get_fullname($uid);?>)</font> |<a href='logout.php'>Logout</a>|<a href='index.php'>Home</a></p></center>


<hr />
<br/><br/> 
<center>
<div id="content">
<form action="PostReply.php?Blog_ID=<?echo $Blog_ID?>" name= "com" method="post">
<input type="text" name="Comment_Detail" placeholder="write Comment here">
<br /><br />

<button class="btn btn-lg btn-primary" onclick="return(Comment());"  name="reply_submit" type="submit" value="post-Comment">Comment</button>
</form>
</div></center>
<script>
      function Comment() {
        var form = document.com;
        if (form.Comment_Detail.value == "") {
          alert("To Comment Please Write Comment First !!.");
          return false;

          }

      }</script>
</html>
  