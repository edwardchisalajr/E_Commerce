<?php 
session_start();
include_once 'include/class.user.php';
$user = new User();


?>


<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In</title>
      <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css"> 
  <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap-theme.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/Google-Style-Login.css">

    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/user.css">
    <link rel="stylesheet" href="styles.css">
</head>

<body>
    <nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container">
          

             <div class="navbar-header"><a class="navbar-brand navbar-link" href="index.html"><i class="fa fa-fw fa-graduation-cap"></i> ETUTORING </a>
                
                
            </div>
            
        </div>
    </nav>
    <br><br><br>

    <div class="login-card">
        <p class="profile-name-card"> </p>
             <h1>Login</h1>
<br>
          <?php

if (isset($_POST['submit'])) { 
        extract($_POST);   
        $login = $user->check_login($uname, $upass);
        if ($login) {
            // Registration Success
           header("location:home.php");
        } else {
            // Registration Failed
            echo '<h4>Wrong username or password!!! </h4>';
        }
    }

          ?>

        <form class="form-signin" method="post" name="login"><span class="reauth-email"> </span>
            <input class="form-control" type="text" name="uname" required placeholder="Username">
            
            <input class="form-control" type="password" name="upass" required placeholder="Password" id="inputPassword">
            <div class="checkbox">
                <div class="checkbox">
                    <label>
                        <input type="checkbox">Remember me</label>
                </div>
            </div>
            
            <button class="btn btn-primary submit-button"  type="submit" name="submit" value="Login" onclick="return(submitlogin());">Sign In</button>
        </form><a href="registration.php" class="forgot-password">Register Here</a></div>
    
    <footer class="site-footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    <h5>ETutoring © 2018</h5></div>
                <div class="col-sm-6 social-icons"><a href="#"><i class="fa fa-facebook"></i></a><a href="#"><i class="fa fa-twitter"></i></a><a href="#"><i class="fa fa-instagram"></i></a></div>
            </div>
        </div>
    </footer>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
     <script>
      function submitlogin() {
        var form = document.login;
        if (form.uname.value == "") {
          alert("Enter email or username.");
          return false;
        } else if (form.upass.value == "") {
          alert("Enter password.");
          return false;
        }
      }
    </script>
</body>

</html>