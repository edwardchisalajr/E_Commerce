<?php

include_once 'db_config.php';


class Student {
		protected $db;
			public function __construct(){
					$this->db = new DB_con();
					$this->db = $this->db->ret_obj();
			}
			public function reg_user($uname, $Firstname, $Lastname, $uemail,$upass){
			$query = "SELECT * FROM user_tbl WHERE username='$uname' AND password='$upass'";
			
			$result = $this->db->query($query) or die($this->db->error);
			
			$count_row = $result->num_rows;
			
			
			if($count_row == 0){
				$query = "INSERT INTO user_tbl SET username='$uname', password='$upass', fname='$Firstname', email='$uemail', lname='$Lastname', user_type='Tutor'";
				
				$result = $this->db->query($query) or die($this->db->error);
				
				return true;
			}
			else{return false;
				}
			}
			 public function reg_tutor($uname,$upass,$qualification){
			$query = "SELECT * FROM user_tbl WHERE username='$uname' AND password = '$upass'";
			
			$result = $this->db->query($query) or die($this->db->error);
			
			$count_row = $result->num_rows;
			$user_data = $result->fetch_array(MYSQLI_ASSOC);
			$userid = $user_data['User_ID']+1-1;
			
			if($count_row == 1){
				$query = "INSERT INTO tutor_tbl SET User_ID = '$userid',Qualification='$qualification'";
				
				$result = $this->db->query($query) or die($this->db->error);
				
				return true;
			}
			else{return false;}
			
			
			
			}
			

			public function getStudentDetails($User_ID){
					$query = "SELECT * FROM student_tbl WHERE User_ID = $User_ID";
					$result = $this->db->query($query) or die($this->db->error);
					return $result;
			}
			
			public function getTutorDetails($User_ID){
					$query = "SELECT * FROM tutor_tbl WHERE User_ID = $User_ID";
					$result = $this->db->query($query) or die($this->db->error);
					return $result;
			}

			public function getStudents(){
					$query = "SELECT * FROM user_tbl WHERE user_type = 'Student'";
					$result = $this->db->query($query) or die($this->db->error);
					return $result;
			}

			public function getTutor($StudentID){
					$query = "select user_tbl.User_ID,user_tbl.fname,user_tbl.lname,user_tbl.email from tutor_tbl
								  JOIN user_tbl on user_tbl.User_ID = tutor_tbl.User_ID
								  join tutor_student_tbl on tutor_student_tbl.Tutor_ID = tutor_tbl.Tutor_ID
								  join student_tbl on student_tbl.Student_ID = tutor_student_tbl.Student_ID
								  where student_tbl.Student_ID = '$StudentID'";
					$result = $this->db->query($query) or die($this->db->error);
					return $result;
			}
			
			
			public function getTutorUserID($TutorID){
					$query = "SELECT * FROM tutor_tbl join user_tbl on user_tbl.User_ID = tutor_tbl.User_ID WHERE tutor_tbl.Tutor_id = '$TutorID'";
					$result = $this->db->query($query) or die($this->db->error);
					return $result;
			}
			public function getMessages($Tutor_ID,$StudentID){
					$query = "SELECT * FROM message_tbl WHERE Tutor_ID = '$Tutor_ID' AND Student_ID = $StudentID ORDER BY Messege_ID ASC";
					$result = $this->db->query($query) or die($this->db->error);
					return $result;
			}
			
			
			public function sendMessage($Tutor_ID,$StudentID,$Message){
					$User_ID = $_SESSION['User_ID'];
					$Date = date("Y-m-d");
					$query = "INSERT INTO message_tbl SET MesseageText = '$Message',SentFrom = '$User_ID',Student_ID = '$StudentID', Tutor_ID='$Tutor_ID',DateSent='$Date'";
					$result = $this->db->query($query) or die($this->db->error);
					return true;
			}
			
			public function ShowStudentNotification($Student_ID){

				 $query = "select * from student_tbl 
					
								  JOIN meeting_students_tbl on student_tbl.Student_ID = meeting_students_tbl.student_id
								  JOIN meeting_tbl ON meeting_students_tbl.meeting_id=meeting_tbl.meeting_id
								  where meeting_students_tbl.student_id = '$Student_ID'";
					$result = $this->db->query($query) or die($this->db->error);
					return $result;




			}

}
?>