<?php 
include_once 'include/class.user.php';
$user = new User();
// Checking for user logged in or not
    /*if (!$user->get_session())
    {
       header("location:index.php");
    }*/

?>


  <!DOCTYPE html>
  <html lang="en">

  <head>
    <meta charset="utf-8">
    <title>E Tutoring - Registration Form</title>
   <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css"> 
  <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap-theme.css"> 
  <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap-theme.min.css"> 
    <link rel="stylesheet" href="assets/css/Pretty-Registration-Form.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="styles.css">
      
 </head>

  <body>
  <nav class="navbar navbar-inverse navbar-fixed-top" >
        <div class="container">
            <div class="navbar-header"><a class="navbar-brand navbar-link" href="index.html"><i class="fa fa-fw fa-graduation-cap" ></i> ETUTORING </a>

                <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            </div>
            </div>
            </nav>




  <div class="row register-form">
        <div class="col-md-8 col-md-offset-2">
            <form class="form-horizontal custom-form" method="post"name ="reg">
      <h1>Registration Form</h1>
      <?php

if (isset($_POST['submit'])){
        extract($_POST);
        $register = $user->reg_user($uname, $Firstname, $Lastname, $uemail,$upass);
        if ($register) {
            // Registration Success
      $register = $user->reg_student($uname,$upass,$Address, $city, $DOB, $Gender,$CourseID);
            echo "<div style='text-align:center'>Registration successful <a href='login.php'>Click here</a> to login</div>";
        } else {
            // Registration Failed
            echo "<h4>Registration failed. Email or Username already exits please try again.</h4>";
        }
    }
      ?>
<br>
      <form>
      <div class="form-group">
        <div class="col-sm-4">
            <label class="control-label" for="name-input-field">First Name: </label>
        </div>
        <div class="col-sm-8">
            <input class="form-control" name="Firstname" required placeholder="Enter First Name" type="text">
        </div>
    </div>
      
    <div class="form-group">
      <div class="col-sm-4">
          <label class="control-label" for="name-input-field">Last Name: </label>
      </div>
      <div class="col-sm-8">
          <input class="form-control" type="text" name="Lastname" required placeholder="Enter Last Name">
      </div>
  </div>
  <div class="form-group">
    <div class="col-sm-4">
        <label class="control-label" for="name-input-field">Username:</label>
    </div>
    <div class="col-sm-8">
        <input class="form-control" type="text" name="uname" required placeholder="Enter Username">
    </div>
</div>
<div class="form-group">
  <div class="col-sm-4">
      <label class="control-label" for="email-input-field">Email: </label>
  </div>
  <div class="col-sm-8">
      <input class="form-control" type="email" name="uemail" required placeholder="Enter Email">
  </div>
</div>
           

<div class="form-group">
  <div class="col-sm-4">
      <label class="control-label" for="name-input-field">Address: </label>
  </div>
  <div class="col-sm-8">
      <input class="form-control" type="text" name="Address" required placeholder="Enter Address">
  </div>
</div>
<div class="form-group">
  <div class="col-sm-4">
      <label class="control-label" for="name-input-field">City: </label>
  </div>
  <div class="col-sm-8">
      <input class="form-control" type="text" name="city" required placeholder="Enter City">
  </div>
</div>
<div class="form-group">
  <div class="col-sm-4">
      <label class="control-label" for="dropdown-input-field">Gender: </label>
  </div>
  <div class="col-sm-8">
      <div class="dropdown">
          <select name = "Gender" button class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-expanded="false" type="button">
          <ul class="dropdown-menu" role="menu">
              <li role="presentation"><option value ="Male">Male</option></li>
              <li role="presentation"><option value ="Female">Female</option></li>
              <li role="presentation"><option value ="Other">Other</option></li>
              
          </ul>
        </select>
      </div>
  </div>
</div>
<div class="form-group">
  <div class="col-sm-4">
      <label class="control-label" for="name-input-field">Date of Birth: </label>
  </div>
  <div class="col-sm-8">
      <input class="form-control" input type="date" name="DOB" required>
  </div>
</div>


  <div class="form-group">
  <div class="col-sm-4">
      <label class="control-label" for="dropdown-input-field">Course: </label>
  </div>
  <div class="col-sm-8">
      <div class="dropdown">
          <select name = "CourseID" button class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-expanded="false" type="button">
          <ul class="dropdown-menu" role="menu">
          
              <li role="presentation"><option value ="1">Business Technology</option></li>
              <li role="presentation"><option value ="2">Information Technology</option></li>
          </ul>
          </select>
      </div>
  </div>
</div>


<div class="form-group">
    <div class="col-sm-4">
        <label class="control-label" for="pawssword-input-field">Enter Password: </label>
    </div>
    <div class="col-sm-8">
        <input class="form-control" type="password" name="upass" required  required placeholder="Enter Password:">
       
  </div>
    </div>
    <div class="form-group">
    <div class="col-sm-4">
        <label class="control-label" for="pawssword-input-field">Repeat Password: </label>
    </div>
    <div class="col-sm-8">
        <input class="form-control" type="password"  required placeholder="Repeat Password:">
       
  </div>


        
         <br><br><br><br><br>
            
            <button class="btn btn-primary submit-button"  name="submit" value="Register" onclick="return(submitreg());" button type ="submit" type="button">Submit Form</button>
            <button class="btn btn-danger submit-button" <i class="fa fa-fw fa-graduation-cap" button type ="reset" type="button">Clear Form</button>
           
              <br><h4><a href="login.php" >Already registered? Click Here!</a></h4>
            
           
        
      
    

    <script>
      function submitreg() {
        var form = document.reg;
        if (form.uname.value == "") {
          alert("Enter Username.");
          return false;
        } else if (form.city.value == "") {
          alert("Enter city.");
          return false;
        } else if (form.upass.value == "") {
          alert("Enter password.");
          return false;
        } else if (form.Firstname.value == "") {
          alert("Enter FirstName.");
          return false;
		}else if (form.LastName.value == "") {
          alert("Enter LastName.");
          return false;
		}else if (form.uemail.value == "") {
          alert("Enter Email.");
          return false;
		}else if (form.Address.value == "") {
          alert("Enter Address.");
          return false;
        }
      }
    </script>
      <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js">


  </body>

  </html>